# Filling Your Sales Pipeline with Leads

> “Farming is work. But, as I said before, what else are you going to do
> while you aren’t selling houses? I farmed.”

—Cathy Turney, *Laugh your way to Real Estate Sales Success*

An empty sales pipeline is the biggest stressor for a real estate agent.
As soon as you close one deal, you need to be on the lookout for the
next. Not every client needs your services right away. Some might take a
few weeks or even a few months before they are ready to buy or sell. The
best way to combat this is to always be prospecting, even when you are
busy with clients. That way, you can maintain a steady workload without
significant gaps between closings. This chapter provides a blueprint for
doing just that.

## Real Estate Sales Funnel

The **sales funnel** (also called a **sales pipeline**) is a visual
model that illustrates the customer’s journey from first contact to
final close. It is called a “funnel” because it starts wide at the top,
capturing many prospects, and narrows to a smaller group of actual
closings at the bottom. Some prospects will not end up buying or
selling, or they will choose another agent, which is why the funnel
narrows. The sales process moves people through this funnel.


There is a science to the sales funnel that you can use to predict your
income and strategize improvements. For example, let’s say you had 8
closings last year and met 150 people who were looking to sell. You can
calculate your conversion rate as 8/150 = 5.3%. We can also invert that
number to determine how many prospects you need to meet to generate a
single new closing, which is 150/8 = 18.75.

To conduct a more detailed analysis, we can divide the sales process
into three stages: lead incubation, the listing presentation, and
finally, a successful closing. For a prospect to result in a commission,
they must first agree to a listing presentation, then sign a listing
contract, and finally, the property must sell. At each stage, some
prospects will not work out and will not result in a commission. 

For lead incubation, you met 150 people, and 30 agreed to sit down for a
listing presentation. That means you have a 30/150=20% chance of
convincing a prospect to seriously consider you as their agent. In other
words, to generate a single listing presentation, you would need to meet
150/30=5 new prospects.

For the listing presentation conversion rate, you had 30 presentations
that resulted in 10 listing contracts. That means you have a 10/30 = 33%
chance of success in getting someone at your listing presentation to
sign on the dotted line and agree to use you as their agent. In other
words, for every new listing, you need to make 3 listing presentations
(30/10). 

In your case, out of the 10 listings you had, you closed 8. This means
you had an 80% chance of success in converting a listing into a closing
(8/10).


Your real estate CRM can help you calculate these key statistics. This
helps you better understand the improvements you might make at each
stage and the impact those changes might have on your overall annual
income.

What would happen if you improved the quality of your listing
presentation and increased your success rate from 33% to 50%? In this
case, you would go from 10 listings to 15. With a listing-to-closing
success rate of 80%, you would close 12 homes instead of the 8 you
closed last year. Your ability to be more effective with the same number
of leads would dramatically increase your income.

One of the most common areas for improvement is your follow-up with
prospects at the earliest stage of the sales pipeline. While most agents
excel at initial contact, they often fail to follow through over weeks
or even months. Industry research shows that it takes multiple points of
contact to convert a lead, yet most agents follow up only twice on
average[16]. Your CRM can help you systematize follow-up, thereby
increasing that conversion rate.

Assuming you have tightened your follow-through and are successfully
taking listings through closing, the next area to explore is how many
new prospects you meet each day and how that directly determines your
commission income. You can then decide whether it is worthwhile to
dedicate additional time and money to lead generation.

You can use your real estate CRM to identify which lead sources are
working for you and which are not. Some lead sources might generate more
leads, but that doesn’t necessarily translate into more closings. For
example, you might find that working with prospects who have credit
problems results in fewer closings per lead than working with first-time
home buyers who don’t have credit problems. You need to look at your
entire sales funnel to determine which lead sources are most efficient
for you. If credit-repair leads are easier to generate, you might find
the lower conversion rate acceptable. Your real estate CRM helps you
identify these patterns and adjust your strategy accordingly.

Many agents believe that working a bit harder can increase their income.
That is likely true, especially when you are new, but you will
eventually reach a point where you sacrifice your quality of life to
increase your income. This is where working smarter, not just harder,
becomes critical. I recommend leveraging the information and analysis
your CRM provides to identify ways to become more effective. If you can
redirect your efforts from inefficient lead sources to those that are
easier to convert, you'll generate more income with the same effort. A
new agent must initially work hard to fill their funnel with every
possible lead. An experienced agent uses their CRM data to work smarter
and refine the funnel for maximum efficiency and profit.

In the example above, a 33% chance of converting a listing presentation
into a signed contract is at best average. A reasonable goal is a 50%
success rate. A great way to work toward that goal is to find a mentor
with a higher success rate and learn from them. Review their listing
presentation materials, sales pitch, and objection-handling approach.


> **Dashboard to Dollars Secret**: Your CRM can track both your deal pipeline as well as your past income. This is perfect for tracking progress towards a specific financial goal like making 20% more this year compared with last year.


Being a real estate agent is a labor-intensive job. A common strategy is
to work with people you already know, such as past clients and friends.
Because lead incubation with friends and past clients requires less
effort than with fresh prospects, you can be more efficient with your
time. You should also expect higher conversion rates when working with a
past client than with a stranger. As you gain experience, you will have
more opportunities to focus on repeat and referral business. It is only
natural to prioritize your most efficient lead sources over less
effective ones, and this shift clearly reflects that reality.

While I have primarily discussed listings, the same strategies apply
equally well to buyer leads. There is a similar sales funnel for buyers.
The three stages are the same: lead incubation, the buyer agency
agreement, and a successful closing. Your real estate CRM will help you
stay on track with follow-up and can even send automated time-release
drip emails to your buyer prospects during that first incubation stage.
New buyers are a particularly good fit for the prewritten, automated
sequences built into your CRM's content library.

A common strategy to improve efficiency is to prioritize listings over
buyers. Buyers are more labor-intensive than listings, and scaling up
buyers is harder. You can drive around only one buyer at a time, whereas
you can have dozens of listings active simultaneously. You can use the
statistics from your CRM to determine the mix of listings and buyers
that works best for you.

Listings also have a synergistic effect on your ability to generate
fresh buyer and seller prospects. A single listing can be used to market
yourself and generate multiple buyer leads. Some of this lead generation
will come from potential buyers arriving at your doorstep. For example,
each time you conduct an open house, you’ll meet buyer leads. A less
direct source of leads comes from your yard signs, which serve as
advertising and generate calls from interested buyers.

While those methods generate leads with little effort, you can also
actively capitalize on your listing by seeking prospects in the
neighborhood. When marketing, ensure the central theme of your
promotional activities and materials is the listed property. For
example, send “Just Listed” and “Just Sold” postcards to the
neighborhood. Another example is walking the area with a flyer before
each open house and introducing yourself through door-knocking. Finally,
once you close on the property, you can announce the home sale to the
neighborhood through more door-knocking or postcards. You could even
sponsor a block party to give the new homeowner an opportunity to meet
the neighbors and for you to network. These activities could easily
motivate other sellers, who are impressed by how you flawlessly handled
the sale and the top-dollar price you negotiated.


> **Listing Leverage Secret**: Maximize the benefits of each of your listings by treating it as a buyer-generation machine: use yard signs, call capture, open houses, and neighborhood marketing to create at least one additional buyer closing for each of your listings1.


The concept that each listing can be expected to produce
at least one additional buyer-side closing originates from The
Millionaire Real Estate Agent by Gary Keller, Dave Jenks, and Jay
Papasan.↩︎


A third scaling strategy is to hire an assistant or bring on a partner.
You can use sales funnel data to determine whether this change is
justified and which activities the new person could support. Your real
estate CRM is an ideal tool for coordinating with a partner or
assistant. It lets you assign tasks, track completion, and delegate work
to others, freeing you for higher-value activities like listing
presentations.

Your real estate CRM helps you identify these patterns and adjust your
strategy for maximum efficiency. While this book covers the core
systems, my second book, *Real Estate CRM Mastery*, delves into advanced
strategies for growing your business. It offers a multi-year plan to
develop a geographic farm and shows how to build a predictable referral
business from your sphere of influence. These long-term, system-driven
lead sources enable an experienced agent to move beyond chasing
individual leads and build a stable, leveraged business.

While the sales funnel is a great way to track your entire deal
pipeline, a real estate CRM also helps you track each prospect and their
progress through the sales process. This allows you to identify which
leads need more nurturing and to schedule follow-up calls accordingly.

For your listings, your CRM provides ample notice of listings that may
expire without a deal. By collecting showing feedback in your CRM, you
can share a service report with your seller that scientifically
documents what the market is saying about the property, its price, and
condition relative to the competition. This allows you to discuss the
possibility of a price adjustment and the need to extend the listing
agreement deadline well before it expires.

By entering the source of each prospect into your CRM, you can determine
which lead sources are working and which are not. With that information,
you can focus your efforts on getting more of the types of leads you
prefer and fewer of the ones that are less likely to close. Your CRM can
even perform a detailed analysis to identify which lead sources convert
at a higher rate than others. It is not just the quantity of leads, but
also their quality, that needs to be considered.

## Daily Prospecting Habits

Daily prospecting is an important factor in generating consistent income
for a real estate agent. By creating a daily prospecting habit, you
focus on the early stages of your sales funnel rather than just on
closings and clients.

Your real estate CRM is the command center that keeps you organized and
on track. Persistence pays off in prospecting, and your CRM can help you
avoid the pitfall of giving up on a lead too soon. You also need to
space out your prospecting over time. Nagging a prospect too frequently
will not help, and ignoring a prospect will not yield results. Your real
estate CRM allows you to scientifically regulate the frequency and types
of communications you send to maximize your results.

The first step is to set aside time each day for formal prospecting. The
best way to do this is to block out **office hours** in your calendar
specifically for outreach and relationship-building. Office hours are a
scheduled time for making outgoing phone calls. Use your CRM to generate
a daily outbound call list. Use the CRM’s click-to-dial feature to make
your calls. Prepare for each call by opening your notes from previous
conversations, taking new notes, and scheduling a follow-up call—all
within your CRM.


> **Prospecting Power Hour Secret**: Schedule time in your calendar each day for outbound prospecting. By reserving this time, you can maintain a steady flow of new prospects. Think of this as your “me” time. At other times you are helping people buy and sell, but during office hours you are dedicated to generating new leads.


While it might be tempting to focus more on active clients than on
prospecting, you should resist the urge to neglect your prospecting
efforts. By scheduling time on your calendar, you ensure a balanced
approach.

Before making a single outgoing call, be prepared. Develop scripts for
each prospecting activity so you know what to say. Whether you're
canvassing a neighborhood before an open house, calling a new internet
lead, or door-knocking, a script helps you speak confidently. Also,
pre-qualify your prospects as part of your prep. For a buyer, ask
whether they have a loan arranged, what their timeframe is, and whether
they have the down payment or need to sell first. If you don’t know the
answers, use those as discussion topics when you call.

You can use the real estate calculators integrated into your CRM to
support this process. While others might view real estate agents as just
salespeople, you should see yourself as a trusted advisor, helping your
clients manage their largest asset: their home. It is essential that
your client can afford their home purchase, that it makes financial
sense, and that it also meets their housing needs.

Prospecting goes beyond data and scripts; it's about the art of building
connections and rapport. A great way to start conversations is
through community engagement, which offers a sincere social reason to
reach out that fits the moment and reduces resistance. Instead of cold
calling, you might try caroling during the holidays, handing out flags
on the Fourth of July, or delivering pumpkins for Halloween in your farm
neighborhood. These seasonal pop-bys help you participate in your
community and naturally lead to conversations.

When you connect with people, be an active listener and encourage them
to talk about themselves. Your success comes from genuinely listening to
their answers. This reflects a core principle from Dale Carnegie’s
legendary book, *How to Win Friends and Influence People,* which states,
"You can make more friends in two months by becoming interested in other
people than you can in two years by trying to get other people
interested in you."

Ask about their career, hobbies, favorite sports teams, and vacation
plans. Small details, like knowing which pets your friend has, make a
big difference because they help you recommend homes with yards that
meet those pets’ needs. This information is valuable intelligence that
helps you understand their motivations and needs. Capture all this
information in your CRM. Remembering a prospect’s children’s names or
favorite sports team provides continuity over the years. By paying
attention, you build trust. You can then provide professional advice
based on your understanding of their specific requirements and what will
make them happy.

Not every prospect will be ready to buy or sell immediately, which is
why systematic, long-term follow-up is essential. After initial contact,
you should assign a touch-cycle task to maintain regular contact. It is
easy to make a single follow-up call, but a CRM is needed to schedule
consistent follow-ups throughout the entire lead incubation period.

Be flexible with your communication methods. If a phone call goes to
voicemail, follow up with a text message. If you have their physical
address and the phone number is disconnected, drop off a packet of
information at the house. It is best to schedule follow-ups one at a
time, adjusting the timing and method based on your last interaction. A
rigid, multi-step plan that cannot adapt to your prospect’s changing
situation will fall apart quickly if anything goes wrong - and it will!

A well-equipped real estate CRM includes a library of pre-built drip
email sequences for dozens of client situations, including first-time
homebuyers, veterans, investors, and those looking to downsize. This is
particularly valuable for new agents, who can use the library for
inspiration and to understand different ways to nurture leads of all
kinds.


> **Ping, Don’t Pester Secret**: Time released emails tend to work best when used in moderation and when spaced out at least a week apart. If you send too many emails, people will just opt out. You are less likely to convert someone who finds you irritating.


You can use your CRM’s content library to provide value, but don’t start
a drip sequence until you understand your first prospect’s goals.
Generic drips can irritate prospects and prompt them to opt out. A
first-time homebuyer needs different information than a savvy investor.
Similarly, use bulk emails sparingly. Sending information about your new
listing to someone searching in a different city or price range shows
you aren’t paying attention to their individual needs. Keep your
communications targeted and relevant. Finally, recognize that leads have
a limited shelf life. Track when each prospect was created, and review
your database at least annually to identify old, unresponsive leads.
Mark these contacts as “Cold” using a category so you can focus your
energy on those most likely to convert into income.

New business from old clients and referrals from those who know you are
just as important as fresh leads. Your real estate CRM can track who you
have contacted, and when, and it can create a call list of past clients,
friends, and family you should reach out to. Calling a friend on their
birthday, the anniversary of their home sale, and sending annual
Christmas cards are just three examples of relationship-building
activities you should use with people in your sphere of influence. From
a business perspective, these personal "touches" are a form of long-term
prospecting, but their strength lies in genuine gestures of
friendship[17].

You should also identify a “Top100” category of people in your contacts
database. These are the individuals most likely to recommend you or use
your services again. Place these people on a 90-day touch cycle, so you
contact them every three months. This way, you have an opportunity to
maintain a good relationship and hear about referrals and repeat
business opportunities. For everyone else in your contacts database,
consider calling them at least once a year just to say "hi."

A successful sales pipeline is built through consistent daily habits of
prospecting and nurturing leads. Dedicate time each day to finding new
prospects and nurturing existing leads. Use your CRM’s organizational
tools to stay on top of your pipeline. This increases your chances of
converting prospects and maintains a steady flow of new leads. Your CRM
can turn the chaotic process of lead generation into a reliable system
that fuels your business for years.

## Using Floor Time

**Floor time** is when an agent is physically present in the brokerage
office to handle general inquiries from potential clients who call or
walk in. This duty, also called “up time” or “opportunity time”, allows
agents to generate new leads and helps the brokerage ensure a
representative is available to answer general questions the receptionist
cannot. Floor time is usually assigned to new agents. Why? Because the
people who drop by are unqualified leads, and experienced agents often
prefer to work with referrals and their sphere of influence instead.
However, a new agent may not yet have that pool of people to draw on and
is therefore more likely to benefit from floor time.

Some people you meet during floor time will be highly motivated buyers.
They might want to start looking at homes with you right away. While you
might be tempted to start right away, your first step should be to
pre-qualify your buyer. I recommend using your real estate CRM to gather
as much information as possible during the initial interview. If the
buyer has not been pre-qualified for a loan, connect them with a loan
officer.

When you meet someone new, get to know them. Find out why they are
thinking of buying or selling. This might be due to a life change, such
as a new baby, marriage, divorce, or a job change. You also need to
understand their financial circumstances. If they are buying, what price
range are they considering? What is the timeframe? A great way to break
the ice is to use one of the real estate calculators built into your
CRM.

According to the National Association of Realtors, nearly 40% of buyers
take 70 days or more from their first contact with an agent before
making an offer[18]. Because this process takes time, you should use
your CRM to manage your follow-up, nurturing your prospect while they
get prequalified for a loan and become familiar with homes on the market
that meet their needs. Your ability to manage the transition from
initial excitement to a qualified buyer and, eventually, to an offer is
key to earning your commission check. Buyers are likely to be
opportunistic about which agent they use, so your follow-up will be key
to converting them into a closing.

## Open House Strategies

An **open house** is a scheduled event in which a real estate agent
invites the public to tour a home for sale. During a set time, typically
on a weekend afternoon, potential buyers can walk through the property
without a private appointment to get a feel for the space. It’s a
marketing tool for sellers and an opportunity for agents to attract
interest and gather feedback.


> **Notable Nametag Secret**: You should consider wearing a nametag during open houses and floor time. This will help people remember your name and feel less awkward speaking with you. Your nametag clearly identifies you as the host, making it easier to solicit feedback and gather contact information. When you are face-to-face with someone wearing a nametag, they are more likely to address you by name verbally, reinforcing the connection in their memory.


An open house is a great opportunity to generate leads. While one goal
is to sell the listing, it’s also ideal for meeting new buyer prospects
and attracting neighborhood 'looky-loos' who might consider selling
their homes soon. You will rarely find another chance when so many
people are eager to talk with you.

A successful open house depends on thorough planning. Your CRM can help
you create a checklist of tasks to complete before, during, and after
the event, increasing your chances of attracting new clients and
possibly even a buyer for that house. Post a sign the week before the
open house with the date and time. Promote the open house on your
broker’s website and on syndication platforms like ListHub, which
distributes the information to Zillow and Realtor.com. Use social media
platforms like Facebook and post on local sites such as Nextdoor. You
can also use Instagram Stories to promote the event’s Facebook Live
stream.

Consider partnering with a mortgage broker to produce a co-branded flyer
with your information on the front and the lender’s sample payment terms
on the back. It would be reasonable to ask the mortgage broker to cover
the flyer printing costs and share some of the other open house expenses
in exchange for their listing on the back of your flyer.

An open house is the perfect pretext to meet people in the neighborhood.
A few days before, walk the neighborhood to connect directly with
residents. Bring a **door hanger** or a flyer and knock on each door
near the open house address to announce the event and extend a personal
invitation to drop by. A door hanger is a small, printed card with a
cutout that slips over a doorknob and stays in place if no one answers,
so your invitation and contact details remain at the home.

Real estate coach Tom Ferry recommends this direct approach, framing it
as a “neighbor-only preview” and a chance for neighbors to help “pick
your new neighbor.” This is called **circle prospecting** and can be
effective. Some of the best salespeople for a home are going to be
people living in that neighborhood. You might also bump into a neighbor
who is considering selling.

I recommend getting a large magnetic vinyl sign for your car that
displays your contact information, including your name, brokerage,
company logo, and a portrait photo of yourself. With this sign on your
car, you are advertising yourself whenever you are in the neighborhood.
The presence of your car with its sign in front of the open house also
signals that you are inside. This is ideal not only for open houses but
also for showings, where you might meet a buyer at the property.

On the day of the open house, set up directional signs with festive
balloons to guide traffic and create a festive atmosphere. Before the
open house begins, work with your seller to clean, declutter, and
depersonalize the house. Consider baking a store-bought cookie dough
roll before visitors arrive. The aroma of freshly baked goods is one of
the oldest tricks in the book because it works. Scent is directly linked
to the brain’s center for emotion and memory, instantly evoking
positive, nostalgic feelings of home, safety, and comfort[19]. The goal
is to make the unfamiliar house feel familiar. This welcoming atmosphere
can predispose buyers to a positive evaluation of the property, and you
can offer visitors a warm cookie as well.


> **Barefoot Buyer Secret**: Place a sign by the door asking people to remove their shoes or to put on the disposable booties you provide. This keeps the home clean, shows respect for the owner, and gives buyers the impression that the property is of high quality and has been well cared for.


Your goal at an open house is to build relationships. Greet each guest
with eye contact and a friendly handshake. Answer any questions they
might have, but most importantly, ask questions to find out what the
prospective buyer is looking for and what they think of the home. If the
current house isn’t right for them, or if specific features make it a
poor fit, offer to show them other homes that might be more suitable.
Explain that, as a real estate agent, you are licensed to show them any
home listed on the MLS. This pivots the conversation from selling one
specific house to your expertise in the entire neighborhood and all the
available homes, perhaps even a few that have not yet been listed. Your
expert understanding of the town and the neighborhood makes you the
perfect agent to find this buyer their forever home.

Rather than relying on a paper sign-in sheet, use an iPad or tablet with
the open house app built into your real estate CRM. That way, guests
enter their information directly, and it feeds into your CRM,
eliminating manual data entry. This method is excellent for gathering
information such as the visitor's name, email address, and whether they
are already working with another agent.


> **The Seller Security Secret**: Insist on collecting contact information for every visitor at an open house. Greet every visitor with a firm but friendly script: “Welcome! For security purposes, the seller requires every guest to sign in before touring the home.” That way you can capture contact information for follow-up.


You should also bring printed materials, including property flyers,
floor plans, and FAQs covering Homeowners Association (HOA) details and
local amenities.

While a typical open house is held on a Saturday or Sunday afternoon
after church and lunch, consider scheduling it at unconventional times.
This tactic can help you attract buyers with nontraditional schedules.
It's especially effective for reaching retired buyers or those who work
odd shifts, such as firefighters, hospital staff, and doctors.

Another option you should consider is using the call capture feature
built into your real estate CRM. Instead of relying on your CRM’s open
house form, ask each visitor to text or call your call capture number
and enter a specific three-digit code. This method is faster for the
guest and has the key benefit of capturing a verified mobile number. The
main advantage of this approach is its simplicity. You can also increase
the incentive for visitors by telling them that by texting your code to
that number, they will receive the home flyer with the floor plan, home
details, and asking price.

You can use your CRM to send each visitor from your open house a quick
email or SMS while your name is still fresh in their minds. The best
time is a few hours after the open house, but no later than 24 hours.
Thanks to the open-house form in your CRM, you already have their names
and phone numbers. First, identify each person’s level of interest.
Focus on visitors who showed serious interest in this specific
property—they require immediate, personal follow-up to discuss their
interest in the home. Next, reach out to unrepresented buyers who liked
you but not the house. Offer your expertise to help them find their
perfect forever home. As an expert in that neighborhood, you're the
best-qualified agent to do so.

You can also solicit feedback by sending an email that includes a link
to the **showing feedback form** built into your real estate CRM. When
clicked, the link displays a photo of the open house and asks a few
simple questions to gauge the prospect’s interest level and their
impression of the home's condition and price. Don’t underestimate the
value of a simple text message. For example: “Jake here from the open
house at 12 Main Street. What did you think of the home?” Sending a
brief text message can often give you faster, more reliable results
because many people respond quickly to texts and are willing to share a
one-line answer.


> **Flyer Feedback Secret:** Use the questions people ask at your open house to refine and improve your flyer and MLS descriptions. Sometimes specific features, like stainless steel appliances, or quartz countertop become trendy. If you can highlight desirable features, that can maximize its appeal.


You should also contact your seller after the open house to share how it
went. The easiest way is to send your seller a link to the listing
service report, which summarizes who saw the property and any feedback
they provided. Even negative feedback is helpful because it can start a
conversation about a necessary price adjustment or other changes that
might improve the chances of an offer.

Traditionally, an open house is a public event hosted by the listing
agent to attract potential buyers. A few variations focus on marketing
to real estate agents and brokers instead. A **broker open** is a
single-property open house for agents, while a **broker caravan** is a
scheduled tour of multiple properties in one day. The core difference is
the number of properties shown.

Both the broker open and the caravan are private events hosted
exclusively for other real estate professionals, often held before the
listing becomes public. The primary purpose is for agents to preview the
home and generate buzz within the agent and broker community. Agents can
share feedback on price and condition with the listing agent and network
with other professionals. This also allows them to preview the home
before showing it to their qualified buyers. Offering refreshments is a
popular strategy among listing agents to attract other real estate
professionals and make a positive impression.

As the host, I recommend collecting contact information from all
visitors. That way, you can share price adjustments and other updates
about the listing with attendees. You can also follow up with any agents
who mention they have a client who might be a good fit as a buyer.


> **Broker Bowl Secret:** Place a fishbowl at your broker open with a request that agents drop their business card in the bowl with the price they think the home will sell for written on the back of the card. The person who comes closest wins a gift card to the restaurant of their choice and bragging rights as the most accurate agent. For the price of a gift card, you have just gotten a professional Broker Price Opinion (BPO) from the people most qualified to provide it. By making it a competition, you are less likely to get lowball estimates. You can load the contact information from these business cards into your real estate CRM by using a smart phone app which converts photos of business cards into contact records.


Each open house event gives you an opportunity to collect contact
information. With call capture, the open house form from your CRM on an
iPad, or simply scanning business cards with an app on your phone, you
can have your CRM capture this information without having to hand-enter
anything. Then, you can follow up using your CRM’s email, text
messaging, and click-to-dial functionality.


The attention your open house generates also elevates your profile in
the neighborhood, boosting your mindshare and increasing the likelihood
that other homeowners will choose you as their listing agent when they
are ready to sell. In short, an open house is a powerful marketing tool
that can accelerate the sales process.

## Paid Lead Sources

**Paid lead sources** are services that generate buyer or seller leads
in exchange for a fee. These leads are collected through online
advertising, property search websites, or marketing campaigns and then
sold to agents. Common examples include Zillow Premier Agent,
Realtor.com, and Homes.com. Agents pay per lead, per impression, or via
a subscription model. While paid lead sources can quickly fill a
pipeline, the quality of those leads tends to be lower than that of
other leads.

Some leads will be fraudulent and have no real person associated with
them. Others may be in the wrong geographic area and are therefore
useless to you. Still others might not be serious buyers or sellers, or
might be unable to buy due to poor credit or insufficient income.

The most challenging part of these leads is the limited contact
information you are provided, often just an email address or phone
number. This makes initial contact and follow-up difficult. For example,
you might get a list of 30 people, and only one person will answer the
phone when you call.

For this reason, you should expect the conversion rate for these kinds
of leads to be low and that they will require considerably more
persistence than other kinds of leads. You must use your real estate CRM
to systematize contacting and following up with these leads. With these
kinds of leads, it is a numbers game, which makes using the automation
features of your CRM, such as email feed, click-to-dial, drip email, and
touch cycle, critical.

You should expect that any paid lead source will provide you with
non-exclusive information. Other real estate agents will also receive
the same lead information. So, competition is fierce.

Paid lead sources like Zillow or Realtor.com can be integrated into your
real estate CRM via an email feed. This way, contact information is
automatically added to your CRM, and you receive instant notifications
by text message and email. Studies show that quick responses to these
leads are crucial for conversion. You should expect that other agents
have been given the same loads, and the first agent to establish rapport
will win that client.

As a new agent, I recommend that you first maximize every opportunity to
generate leads through your own efforts, such as open houses, floor
time, friends and family, and community involvement, before investing in
paid lead sources. Paid lead sources naturally cost money, and as a new
agent, the last thing you want is to spend a lot of cash up front.

There are several advantages to paid lead sources, which is why you will
eventually want to experiment with them. You can think of paid lead
sources as channels through which you can control the flow of leads. The
more you pay, the more leads you get. If you need leads quickly, paid
lead sources are a great option.

A third type of paid lead source is **data aggregation,** which can
provide you with a list of recent FSBOs, expired, probates,
foreclosures, and non-owner-occupied homes. Instead of generating new
buyer or seller inquiries through advertising, these systems aggregate
existing data and deliver it in a format that can be loaded into your
real estate CRM.

These lead sources can deliver multiple leads of the same type, such as
FSBOs. This is particularly valuable if you've developed a successful
strategy for nurturing that specific type of lead. For instance, you
might have perfected a highly effective campaign for reaching FSBOs,
using a carefully timed sequence of letters, phone calls, and postcards.
You can use a paid lead source to generate these leads, and your CRM can
nurture them.

Unlike leads generated from advertising, these leads are unaware they
are leads. They did not click on an ad or indicate they needed a real
estate agent. These leads are not live and will not be loaded
automatically via the email feed. Instead, you would load these leads
weekly using your CRM’s valet import feature. For example, you might
load a list of all the new FSBOs in your target area each week.

Due to the aggregated nature of these leads, you are likely to have
several ways to reach each prospect, including email addresses, phone
numbers, mailing addresses, and property addresses. However, some of the
information, such as email addresses and phone numbers, may not be
particularly accurate because it was compiled by combining data from
multiple sources. Also, since you are working with prospects who are not
expecting to be contacted, they might not answer the phone or hang up on
you if you call them directly.

This means that incubating these leads will require a different
approach. The best way to work these kinds of leads is to use your CRM's
automation features to create a multi-step task plan that involves
multiple points of contact and communication channels. You might start
with a printed letter, then a phone call, then a text message, and
finally a series of postcards and even a drive-by visit.

The main advantage of these aggregated leads is that you can quickly
generate hundreds of the same type of lead. This means you can work
leads rapidly and often have too many rather than too few. Working these
leads is ideal for an agent who is highly technical and proficient with
their CRM’s automation features. The key to making these leads work is
the systems you build and perfect over time. Like paid lead sources,
working aggregate lead sources is a numbers game.

In some cases, you can gather this information yourself from tax
records, your MLS, or lists provided by a local title company. While
this is useful when starting out, the main value of these lead
aggregators is the additional information they provide. For example,
they will look up phone numbers to see if they are on the national Do
Not Call (DNC) registry, a database maintained by the Federal Trade
Commission (FTC) that allows consumers in the United States to opt out
of receiving unwanted telemarketing calls. Real estate agents must check
their prospecting lists against the DNC before making cold calls, as
contacting registered numbers without permission can result in
significant fines and legal penalties.

Companies that provide these kinds of paid leads are notorious for
overpromising and underdelivering. They also tend to favor lengthy
contracts, often a year or longer. As a result, it is easy to get stuck
in a contract for a service you do not want. For these reasons, I
recommend requesting an initial sample of the data to review the quality
and starting with a short-term contract. If the leads are as great as
the salesperson says they are, you can always convert your monthly
membership into a longer one.

Another way to generate leads is to create your own website. When
someone finds your website through a search engine like Google, it is
called organic search. In today’s internet, it is increasingly difficult
for a new website to rank organically in Google search results. This is
because there are so many other real estate agents you are competing
with who have established websites. You are also competing with larger
competitors like realtor.com, Zillow, Trulia, and Redfin. 

You can boost your website’s visibility by paying Google, Facebook, and
other organizations to display your advertisements, which, when clicked,
lead to your website. This advertising is called **Pay Per Click
(PPC)**, as you typically pay a fee each time someone clicks the
advertisement.

This kind of advertising involves creating ads that are geographically
targeted to the city where you work and optimized for specific real
estate-related keywords. When someone clicks your ad, they are taken to
a dedicated landing page on your website. The advantage of this approach
is that you have some control over your advertising and website content,
allowing you to be more selective in targeting higher-quality leads and
progressively improving the quality of your results over time.

However, as you would expect, this can take a significant amount of time
and requires specialized skills. This is why most agents will hire an
outside firm to manage their website's organic and PPC promotion for a
fee.

If you are interested in pursuing paid lead sources in more detail, I
recommend my book, *Real Estate CRM Mastery*, for more experienced
agents looking to take their real estate game to the next level. Paid
lead sources may lack quality, but they more than make up for it in
quantity. With experience, you will improve your ability to convert
specific types of leads, such as FSBOs, and refine the automated systems
that maximize conversion rates. Over time, you will be able to convert
paid leads efficiently and profitably. For example, once you're skilled
at turning FSBO leads into listings, you can leverage economies of scale
by purchasing FSBO leads and automating your efforts.

## Rentals

You might think your job is strictly helping people find and sell their
homes. I recommend expanding your job description to include rentals as
well. Your MLS also lists properties for rent. Typically, you would be
paid a “bounty” for finding a renter for a property. To do that, you
could list the property on your MLS and use other traditional marketing
strategies, such as posting on Facebook Marketplace and Craigslist and
using yard signs. While that is not as large a payment as a commission
on the sale of that same property, there are several advantages to
providing rental services to your clients.

When the economy is doing poorly and real estate sales are slower,
rentals are likely to pick up. So, by handling rentals, you are
providing yourself with a diversification opportunity when times are
slow in traditional real estate.

You might be working with a buyer who does not qualify to purchase a
home due to insufficient income, excessive debt, or poor credit. Instead
of turning these people away, you could offer your services to help them
find a rental property. The incremental work required is minimal, as you
do not need to prospect to get this client. They are right in front of
you! By helping them find a rental property, you can also maintain your
relationship. That means that when their credit has been repaired or
their income is more stable, you can then help them become a homeowner.
By providing these step-up services, you are helping people achieve
their dream of becoming a homeowner, one step at a time. Rentals could
be the first step toward becoming a real estate agent for life.

You might also work with a client who has short-term needs for which
owning a home is impractical. For example, they may be military and will
only be in town for 2 years. A rental property might be a more
appropriate option for them. Your rent-vs-own calculator can help you
make that determination. Some corporate clients need short-term housing
for executives temporarily transferred. For these clients, fully
furnished rentals might be a preferred option, particularly if they are
coming from out of the country. Being able to provide these services to
corporations opens the door to offering additional services, such as
helping executives sell their homes when they are transferred and
finding homes for employees who will be moving long-term into a new
area. Your ability to offer full-service to a corporate client can make
your services more desirable and, in turn, make you a preferred real
estate agent for ALL their needs.


> **The Lock or Lease Secret**: Don’t assume every buyer you meet should be a homeowner. Use the rent-vs-Own calculator in your real estate CRM to determine if renting makes sense over home ownership.


A third kind of client who appreciates rentals is the investor. You
might be working with an investor to help him purchase a property to fix
up and either rent or flip. In that case, offering to find a qualified
renter is a great way to extend that relationship.

Your connections with an investor can also help you close other deals.
For example, if you start working with another investor who is looking
to sell his rental property, you could connect the two deals and help
one investor purchase from the other through a special tax-favored
transaction called a 1031 exchange, which allows the seller to defer
capital gains tax.

While we have been discussing helping find a renter and being paid a
lump sum for that service, you can also extend your services to rental
management, where you would be paid a monthly fee to manage the
property. This would entail finding a qualified tenant, managing home
repairs, and ensuring the tenant pays on time. You would be responsible
for finding a new tenant should the current one leave. As in other
situations, your ability to step up and offer these services could allow
you to expand your service range in ways that make you a more desirable
real estate agent for some clients.

One final advantage of handling rentals is that it helps you better
understand the rental market and how to service them. This experience
could be useful if you ever decide to be a landlord yourself. Many real
estate agents own rental properties, and doing these services for others
lets you make mistakes and learn on someone else’s dime. It also gives
you economies of scale, since handling five rentals is only
incrementally harder than handling a single rental.

Short-term rentals on platforms like VRBO or Airbnb have also become a
more established option for managing rentals on a short-term basis, such
as for a few days, a few weeks, or even a month. Increasingly, corporate
clients are relying on these kinds of rental properties for their
executives when short-term housing is needed, so you might be able to
leverage your ability to provide these services to corporate clients.

Your real estate CRM can easily track both renters and landlords, just
as you handle the home sales process now. The closing on a rental is
much easier, but the steps are similar.

Some full-featured real estate CRMs can handle rental management as
well. Typically, this includes tracking rental payments due and paid,
organizing repairs, and billing the landlord for your services and any
repair costs. As with your regular real estate business, you must
maintain a good list of service providers in the contacts section of
your real estate CRM, such as a handyman, plumber, house cleaner,
painter, and yard maintenance, among others.

## Commercial Real Estate

Did you know that licensed real estate salespeople can sell both
residential and commercial properties? **Commercial Real Estate (CRE)**
refers to property used exclusively for business purposes or to generate
income, rather than for personal residence. It encompasses four main
categories: Office (e.g., corporate buildings and medical offices),
Retail (e.g., shopping centers and standalone stores), Industrial (e.g.,
warehouses and manufacturing plants), and Multifamily (apartment
complexes with more than four units, considered an income-producing
investment).

In many cases, commercial properties for sale or lease are not on the
MLS but are instead listed on commercial real estate portals like
LoopNet and CityFeet. For this reason, it is helpful to use a real
estate CRM with a **properties database**, also known as a homes
database. That way, you can collect statistics on properties for sale or
lease, such as square footage and building features, independent of your
MLS. If you want to pursue commercial real estate transactions, select a
real estate CRM with a properties database.

Similarly, you would maintain a list of buyers and their needs in your
real estate CRM. You could then act as a matchmaker, connecting the
properties database with the buyers’ database.

Many commercial real estate agents handle both leasing and sales of
commercial properties. This is because the commercial leasing market is
much larger than the sales market. While commercial sales volume in the
U.S. ranges in the hundreds of billions of dollars annually, the total
value of all rent payments across the country's entire commercial lease
inventory is several trillion dollars annually. Some of the best real
estate CRMs can gather both rental and for-sale information from their
buyer and property databases, covering residential and commercial
properties.

There are several reasons you might want to either specialize in or
dabble in commercial real estate.

One advantage of working in commercial real estate is that it does not
follow the same economic cycles as residential real estate. Corporate
tenants and investors seeking multifamily investment properties
typically have a longer timeframe and may be more active when the
economy is down. Working with businesses and investors provides an
excellent form of diversification for you should the economy turn sour.

Another advantage of working with investors is that they often pursue
properties that more traditional buyers might shy away from, such as
higher-priced, distressed, or difficult-to-show properties. By working
with at least one commercial buyer, you can access properties that might
otherwise be challenging to sell.

Commercial buyers may be driven by different incentives than residential
buyers. For example, a commercial buyer might wish to close quickly to
take advantage of tax-favored status under the 1031 exchange rules. A
1031 exchange is an IRS provision that allows a real estate investor to
defer capital gains taxes when selling an investment or business
property, provided they use all the sale proceeds to acquire a
“like-kind” replacement property of equal or greater value. To do that,
they would buy and sell a property within just a few months. This could
give you the opportunity to do two deals for a buyer whose primary
incentive is not price but timing.

Typically, commercial real estate is priced higher than residential real
estate. Deals can be more complex and take longer to close. As a result,
an agent specializing in commercial real estate might handle fewer
transactions, but the final commission is much larger. The average
annual income for commercial real estate agents is more than double that
of residential real estate agents[20]. For these reasons, using a real
estate CRM to track contingencies, deadlines, parties involved in the
deal, and progress toward closing is even more critical than in
residential real estate.

The line between commercial and residential can sometimes be blurry. A
typical scenario is that you help a client purchase or sell a
residential property, and then they call on your services to handle a
commercial transaction. Your ability to deliver a full level of service
provides immense value to your clients. After all, they already know and
trust you for their residential real estate needs, so they might prefer
to work with you on a small commercial transaction, even though you are
not a dedicated commercial real estate agent.

While there are commercial real estate-specific CRMs, it is not uncommon
for commercial real estate agents to use a residential CRM. Residential
CRMs are far more affordable and offer sufficient features to handle
most commercial transactions.

