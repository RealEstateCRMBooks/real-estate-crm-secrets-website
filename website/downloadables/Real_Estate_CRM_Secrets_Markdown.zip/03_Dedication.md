# Dedication

To the more than 150,000 customers of RealtyJuggler. Without your
feedback, this book would not be possible.

