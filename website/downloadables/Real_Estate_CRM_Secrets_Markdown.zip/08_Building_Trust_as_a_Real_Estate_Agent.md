# Building Trust as a Real Estate Agent

> “Many factors go into how a person makes an integrity assessment. One
> of the more subtle, but nevertheless very real, factors is consistent
> congruence. It takes only one disconnect, whether it is a messy
> bathroom, a bad cup of coffee, or an employee with a bad attitude.
> Anything that might be perceived as inconsistent with the first-class
> quality you are trying to project will plant a seed of distrust. Once
> planted, this seed is difficult to weed out.”

—Matt Oechsli, *Influence: The ART of SELLING to the AFFLUENT*

Standing out from the crowd is not easy. You probably won’t be competing
by offering a lower commission or access to exclusive listings. Instead,
to differentiate yourself from other agents, you must rely upon
branding, marketing, and your charm. In this chapter, I describe how to
craft a memorable, authentic brand using your CRM.

## Top of Mind in Your Market

If someone asks a friend of yours, “Do you know of a good real estate
agent?” you want them to reply with your name. The more likely that is,
the more mindshare you have with that person. Your goal is to maximize
this mindshare within your sphere of influence and the geographic farm
you choose.

You’re never going to achieve 100% market share. For example, imagine
your mother has two children who are real estate agents; you'll probably
never capture more than 50% of her attention when she’s considering
which one is the best.

An average homeowner lives in their home for about 10 years before
moving[7]. When they do decide to move, you want to be the first agent
they call. That’s why it’s so important to stay top of mind within your
sphere of influence. Mindshare means something slightly different for
your geographic farm. While people might have your name on the tip of
their tongue, like your friends, if they are ever in need of an agent,
it is tremendously convenient to select an agent who already dominates
that neighborhood. If you have listings in a neighborhood, your yard
signs are the perfect way to build mindshare.

In both cases, you must build brand awareness *before* someone needs
your services. Then, when they decide they need a real estate agent, you
are the agent they think of. When someone is already convinced you are
the right agent for them, it makes converting them into a client so much
easier.

You might also consider targeting **market segments** such as first-time
homebuyers, probate sales, new-home sales, hobby farms, and more.
Focusing on these areas reduces your competition. When you become the
top real estate agent in that niche, word-of-mouth spreads—not just
among the people you're marketing to, but also among other agents. This
boosts your chances of receiving referrals.

By focusing on a specific market segment, you can better understand its
needs, find the right words to sell your services to these clients, and
learn how to handle their objections. You will also gain experience with
the typical problems that arise in this type of deal. This approach
helps you build relationships with lenders and vendors who understand
that particular market segment. These factors lead to greater efficiency
and increase the likelihood that a deal will close and result in a
commission for you. Building a consistent lead pipeline is essential for
your long-term success. If you take the time to thoroughly understand
your market niche, you'll be better equipped to identify which
lead-generation strategies are effective and which are not.

You can utilize the categories feature in your CRM to identify the
market segment each lead belongs to. For example, you might add the two
categories “Buyer, FirstTime” to leads who are first-time homebuyers.
This helps you target those leads for specific automated drip campaigns.
It also enables you to reach out to leads in a particular market segment
with targeted offerings, such as hosting seminars for new homebuyers.
Attending bridal shows to inform engaged couples about the benefits of
buying a home is another option. You could also offer advice on credit
repair. An excellent source of leads is upscale apartment complexes—you
can post flyers near entrances and slip your promotional flyers under
tenants’ doors. All these marketing methods aim to meet the specific
needs of people who haven't yet purchased a home.

Once you master one niche, you can then pursue a related niche. Use the
experience you've gained and the connections you've built. For example,
you might approach a homebuilder to explain your marketing efforts for
new home buyers and express your interest in taking on a few new home
listings, especially entry-level homes. Show how your current marketing
strategies can benefit the new home builder by generating qualified
leads who might not normally consider buying a new home.

## Crafting a Real Estate Brand

One way to differentiate yourself from other agents is to specialize in
a specific town or city. By building a deep understanding of what is
unique about living in the communities you have selected for your
geographic specialty, you are providing exceptional value that other
competing agents can’t. You should include your geographic niche in all
your marketing materials. This is particularly important for internet
marketing, as it allows search engines to better understand the region
you serve. Be realistic about your market area. If you don’t want to
drive more than 20 minutes to show a home, draw a circle around your
house representing a 20-minute drive, and pick a market area within that
circle. Your prospects will appreciate that you know and understand
local market conditions. The deeper your knowledge, the more valuable
your services are. Each neighborhood has its own charm and personality,
and your understanding of what makes it special makes you the
best-qualified agent to buy and sell within that neighborhood.


> **Fit the Family Secret:** When you show your buyer a listing, take the time to understand what they are looking for, not only in features, but from the community. Take time to ask about resources they might appreciate such as churches, schools, hospitals, shops, and even consider ages of the children and their needs. By taking a wholistic approach to the home selection process, you are connecting your buyer with the neighborhood in ways that build enthusiasm for not just the home, but the community as well.


An understanding of local market conditions is essential in getting
clients. We can see this in the National Association of Realtors’
Profile of Home Buyers and Sellers, which consistently finds that
“knowledge of the neighborhood” is a top reason clients choose an agent.
This neighborhood knowledge outranks factors like personal
recommendations or commission rates. Becoming an expert in local
listings, sales, and market trends makes your services more valuable.

Another way to stand out is to associate yourself with a specific
charity or cause. Doing so enhances your credibility and
trustworthiness. This is what social psychologists call the “Halo
Effect.” In his foundational book on persuasion, *Influence*, Dr. Robert
Cialdini explains that a single positive characteristic, such as being
charitable, creates a “halo” that makes people view you as trustworthy,
likable, and competent overall. For instance, you might volunteer at the
local animal shelter. People will associate you with that worthy cause,
helping you stand out.

The best causes are those you have a personal connection to. For
example, if you are interested in the arts, you could become a patron of
the local artist community. You could contact artists looking to
showcase their work and arrange to display it in your empty listings.
You could place cards describing each artist, where they are located,
and how the local artist community helps make the city you love so
vibrant. For your open houses, you could even spotlight a specific
artist and invite them to mingle with visitors or work on their art at
the open house. Throw in some champagne, and you have turned a plain
vanilla open house into a memorable experience.

Another way to stand out is to identify what makes you unique and
leverage that to set yourself apart from the other agents. For example,
if you specialize in selling hobby farms, your marketing materials could
have that cowboy vibe, showing photos of you in your Stetson and boots.

—«◊»—


### Kathi Vaughn 

To build a strong brand, an agent needs to find their identity. Your
identity communicates to clients what matters to you and what kind of
expertise they can expect from you. For Kathi Vaughn, an agent with
RE/MAX Gold in Lodi, California, her identity is represented by her
Stetson cowboy hat. That signature look became the foundation of her
brand, which you can even spot in her tagline, “Home Is Where You Hang
Your Hat.” Kathi quickly realized that clients easily recognized her as
“the cowgirl agent”. While her brand is memorable, it also highlights
her knowledge of her market niche: rural real estate. Because of that
authentic Western image, Kathi Vaughn became the go-to choice for buyers
and sellers of farms and country properties. Like many of the clients
she serves, Kathi values independence and self-reliance. Those values
define her image as an agent, but they also shape how she runs her
business. “I may eventually want to expand out on my own, maybe start my
own agency,” she said. “I always avoided using the brokerage’s CRM
because I wanted to build something that belongs to me, not to the
brokerage.” When crafting your brand, make sure you craft it around an
authentic part of yourself. Let that identity guide your business: from
your headshot and tagline to the tools and systems you use.

—«◊»—

Perhaps you cater to the needs of current and former military service
members. If you are retired military, that can be an additional
connection that increases your value to clients. Military and former
military clients have unique needs. For example, VA loans are different
from conventional loans. Active military service members are often
transferred frequently, which means that they really should select a
home that can be quickly resold without a loss. Finally, for retired
military veterans, the proximity to VA hospitals and veterans’ services
is also essential. Civilians might not understand or appreciate these
requirements. This means a military veteran real estate agent might be
the better option for a veteran buyer.

Your branding is the professional identity you create to stand out in
the market. It should identify who you are and what you do in a way that
is instantly recognizable. Your branding should be included in the
emails you send, in each letter you print and mail, and on your
website’s masthead. You should also use the same branding across
marketing materials such as flyers, yard signs, business cards, and
magnetic car signs. You can also use your branding for promotional items
like pens, refrigerator magnets, and anything else you can think of.
When someone thinks of a local real estate agent, you want them to think
of you, and your branding is one of the simplest ways to accomplish that
goal.

A truism in advertising is that repetition breeds familiarity. This is
why it is important to adopt a consistent branding across all your
marketing materials. We trust what is familiar—a concept Daniel Kahneman
calls “cognitive ease”—in his book *Thinking, Fast and Slow*. He
explains that things that are familiar and easy for our brains to
process feel more likable, more accurate, and safer.

Branding typically includes your franchise or company logo, your name
and title, and a portrait photo of you. The key is consistency. You want
people in your neighborhood to recognize your yard sign and your face,
and to associate you with successfully selling real estate in that
neighborhood. If you were to play an association game, people in your
farm area should reflexively have your name on the tip of their tongue
when asked for the first thing that pops into their head when I say the
word “real estate agent”. If you are at the grocery store, you want
people to recognize you and feel free to approach you with any real
estate related question.

You might also want to include a catchphrase to identify the market area
you serve or any niche market you specialize in. What makes you special,
unique, and different from all the other agents out there? Perhaps you
specialize in a specific city or town? Maybe you specialize in new home
buyers, finding veterans’ homes, and so on. Avoid being too narrow, as
it will limit your market and mindshare. So, think about what is unique
about you - it might even be something about your personality or
history. For example, if you are an agent in Charleston and have a
charming southern accent, you might use the phrase “Selling Charleston’s
Charm”.

Your real estate CRM vendor will help you build a **signature** and
**letterhead** and install them in your CRM. The signature goes at the
end of your emails and printed letters, right after the words Sincerely.
The letterhead is placed at the top of the email or printed letter.


> **The Scan the Scribble Secret:** Emails often feel automated and cold. To stand out you can add a handwritten signature. This small detail makes your communication feel more personal and professional. Sign your name on white paper and take a picture. Upload that picture to your CRM’s signature editor, and now you can include it to all your email and print communications.


You provide your company logo, a portrait photo of yourself, and your
contact information to your CRM vendor. They will then take it from
there and create a letterhead for you. If you have a website, they will
review it to understand the fonts, colors, and other design elements you
are using. Once installed, your emails, printed letters, service
reports, and real estate calculator results will automatically include
your branding. Look for a CRM vendor that offers a complete,
complimentary onboarding service (sometimes called a concierge setup),
including installation of your professional letterhead and signature.

You might be hesitant to include a portrait photo of yourself, but I do
recommend including it with all your branding materials. Not only are
you selling real estate, but you are also selling yourself. A large part
of your job is to meet new people. Your photo makes it easier for people
to recognize you when they meet you for the first time. It also helps
people feel comfortable approaching you in public places, like the
grocery store. You are a local real estate expert, and it is only
natural that strangers will ask you for advice. By using your photo in
your branding, you are giving people permission to approach you and ask
real estate questions, even if they do not know you personally.

Not everyone has movie-star looks, which is why I recommend hiring a
professional photographer for the photos you include in your branding.
You may want to bring a few outfits to your photo shoot so you can try
out a few looks. Have some photos taken with a blank background and
others with something in the background. Each photo style works best for
different types of advertising, and having both available lets you
choose the one that works best based on the situation.

Do you have a distinctive look? For example, do you always wear a white
shirt with your initials monogrammed on the front pocket? Perhaps you
always wear a cowboy hat. Your photos should reflect your genuine
personality so people recognize you. It is not helpful to have a
promotional photo that has been so heavily touched up that you are no
longer recognizable. You should use recent photos for this exact reason.
Older photos might look more flattering, but they will not help people
recognize you.

Branding gives you a consistent look and a professional appearance.
People receive a lot of emails on any given day, and seeing your photo
and company logo increases the credibility of your emails and makes them
more easily recognizable to people who already know and trust you.

I recommend keeping your branding recognizable and straightforward.
People will see your branding in emails on their phones, on yard signs,
and even on refrigerator magnets. Sometimes your branding will be tiny,
like on a pen, and at other times it will be large, like when painted on
the side of a truck. Simple, clear branding will produce better results
than cluttered branding.

Your signature, which is at the bottom of your letters, is the perfect
location for your name, company name, title, license number, phone
number, and email address. I recommend including a single phone number
and email address. Multiple phone numbers can be confusing and often
lead people to call numbers you do not answer. Your signature is also
the best place to add any required legal disclaimers.

Consider creating two versions of your signature. Your email signature
can include clickable social media icons, leveraging the digital format.
For printed letters, a simpler signature is more effective. It saves
space, helping keep your letters to a single page, and avoids the
clutter of non-functional icons.


> **Lead with the Letterhead Secret**: Many CRM’s offer a letterhead feature which allows you place your company logo and portrait photo at the top of your correspondence. That way, this information is immediately visible when someone starts reading your email. Putting your branding at the bottom in your signature is not ideal. Most people decide if they want to delete or read an email within just a second or two and won’t bother scrolling down to see your email signature. So, to maximize the chances someone will read your email, make sure your branding is at the top of all your emails by using the letterhead feature of your CRM.


Your voicemail prompt is part of your branding as well. You should
clearly identify yourself and your organization in your voicemail
prompt. One challenge is using multiple phone numbers, each one with its
own voicemail box. I recommend that you include your mobile phone number
and minimize giving out other phone numbers. That way, you can quickly
answer your calls, retrieve your voicemails, and respond promptly. If
you have a phone number you do not check often, make sure to state that
clearly in your voicemail prompt for that number. When a new prospect
calls you, your ability to respond quickly is a mark of professionalism.
While there are many reasons why you are the best real estate agent in
the world, you should never forget that every real estate agent in your
local market can do precisely what you do, which is buy and sell homes.
Never forget that your replacement is just a phone call away.

One common question agents ask about branding is whether it's worth
having their own domain name. If you own your domain, you can use it for
your website and email—for example, info@SallySellsTexas.com. For agents
just starting out, I recommend getting a free Gmail address and using
the website your broker provides. As you grow, you might decide it's
time for your own domain name. For email, I suggest using Google
Workspace to host your custom domain email. The cost is around $100 a
year, and it offers numerous benefits, including top-tier spam detection
and the ability to sync contacts and calendars with Google.

You have various options for your website, from simple to a full
Internet Data Exchange (IDX) site. An IDX website enables you to display
MLS listings on your site. While a powerful feature, it is quite
technical and involves setup and maintenance fees. Regardless of which
option you choose, always own your domain name personally. This way, you
keep your domain name if you decide to switch hosting companies.

If you are working within a team, you may want to use a team photo in
your branding. In that situation, I recommend using a role-based email
address, such as info@SallySellsTexas.com. A role-based email address is
one associated with a job function, department, or group within an
organization, rather than an individual. The advantage of a role-based
email address is that it allows any team member to use it. So, there is
no expectation that a specific person will be reading that email box.
This allows the team to delegate activities to different staff members.
It also has the added advantage of being fixed, even if your staff might
change over time. For example, if you lose one assistant and hire
another, the email address remains the same.

## Small Talk with Business Cards

When practical, you should match the branding and contact information of
your business cards with your other branding. Unified branding provides
you with multiple opportunities to build recognition, which in turn
builds trust. When a potential client sees your face repeatedly on
websites, park benches, emails, and your business card, you are more
universally recognizable. Not only did you greet them at an open house,
but your image appears on listing after listing as they search online.
You are everywhere. You live and breathe this market, and you are the
person they want in their corner when they need an agent.

How much contact info should you provide on your business cards? You
will want to have your name, title, license number, professional
designations, and your business mailing address. If practical, include
just one website, one email address, and one phone number. The simpler
you make it for someone to reach you, the more likely you are to connect
with them quickly. Providing too many options causes indecision
paralysis and second-guessing.


> **Noted Calling Card Secret**: Leave the back of your business card blank so you can jot a personal note during conversations. This transforms a generic card into a memorable, customized reminder of your interaction. (Make sure your selected card stock will take pen and pencil, so no shiny backs).


In the real estate business, speed is everything. If someone calls you
and you fail to answer, you are allowing that lead to shop around and
find another agent who is not too busy to respond. Aim to return missed
calls within five minutes when possible. Your broker may require an
office phone number in addition to your mobile number on your business
cards. If that is the case, make sure you have an easy way to access
your voicemails remotely, preferably by having them forwarded to you via
email. That way, you can respond to any voicemail within just a few
minutes.

The same applies to text messages. It can be tempting to use an
autoresponder, but be careful with this type of technology. If a lead is
at the point of sending you a text, they are looking to have a
conversation with you personally. We are all used to the inherent delays
in text communication, so don’t feel like you need a robotic response to
explain that you are busy. The last thing you want to do is give them
the impression that you are too busy for them. The impression of
productivity can be a good thing, but you don’t want a new lead thinking
about all the other clients you might be prioritizing over them when
they are shopping for a realtor.

Although business cards are typically exchanged one at a time,
situations such as trade shows or networking events may involve
collecting multiple cards at once. In these cases, the easiest way to
enter them into your database is to take a photo of the card using a
business card-scanning smartphone app. These apps use Optical Character
Recognition (OCR) to convert the information on the business card into a
contact record on your phone.

Business cards are a great way to verify that you’ve accurately captured
a prospect’s contact information. However, some situations make this
difficult. For example, when you provide your business card, but you
don’t receive one in return. In this case, you should not rely on your
prospect to reach out first. Instead, you need to take proactive steps
to confirm their details. One capture method is using the “handshake” or
“bump” feature on your smartphone. This allows two phones to exchange
contact information wirelessly. For a more old-fashioned digital
handshake, you can email or text your prospect and ask them to reply.
Having a phone number is typically more helpful than an email. This is
because a phone number gives you three ways of reaching someone: call,
text, or leave a voicemail.

It is important that your prospect replies to your communication to
verify you’ve captured the correct information. This simple
back-and-forth will also improve the chances that your future messages
will get past any spam filters.

Despite the availability of these modern digital options, exchanging a
physical business card still carries symbolic value and appeals to
clients who appreciate traditional professionalism. For this reason, you
should always provide your business card to everyone you meet, even at
open houses and showings.

Consider leaving your cards at local businesses that experience high
traffic. Apartment complexes, local hardware stores, banks, and moving
companies are all prime candidates, but you could also try your
dentist’s office, the local library, and restaurants. You’ll want to get
permission from the establishment, of course, but even asking the
question could lead to a fruitful conversation with a potential lead or
referral source. The practice of leaving business cards in public places
is long established. While a passive approach like that doesn’t give
your natural charisma and salesmanship a chance to shine the way it
would at an open house, it’s just one more place for members of the
community to learn your name.

##  Blogs to Build Authority

One way to build your local reputation is to create and run a blog on
social media platforms such as Facebook, LinkedIn, and X. This also
helps increase traffic to your website from people searching for local
information. A regularly updated blog written in an informational or
conversational style will give you the best results. When updating your
blog, avoid creating or reposting generic content. Instead, focus on
topics important to the local area. Some examples would be writing about
local real estate market conditions, such as just-listed and just-sold
properties, new housing developments, or changes in mass transit. Your
blog is an ideal place to feature a review of a neighborhood donut shop
or to announce the opening of a new restaurant or brewery. Your blog can
also promote important organizations or events. For example, if you
volunteer at the local animal shelter, you could write about a pet who
is looking for their forever home.


> **The Blog the Block Secret**: Write blog posts highlighting local businesses and attractions instead of only focusing on real estate. This positions you as a community ambassador who is willing to build relationships with business owners and locals.


You should also consider video blogging on YouTube and TikTok. The
advantage of video blogging is that it can reach a larger audience. You
should convert the transcript of your video into a text portion of your
blog entry so that Google can index your words. That way, you get the
benefits of both video and text blogging. Another option is a podcast,
which is an audio-only blog.

Blogging takes time. However, almost all real estate has a seasonal
aspect. I recommend that you look to blogging during the slow months of
your year. For example, in many areas, summer is the strongest season,
while winter is the slowest. So, consider blogging during the winter
months. You can store up your blog entries and space them out throughout
the year.

As a real estate professional, your personal and business lives are
intertwined. You should assume that anything you do online in your
personal life can be traced back to your business. Be careful when you
post comments on social media. If you would not be comfortable with a
client seeing a comment, do not post it.

Be especially careful with comments that could be seen as
discriminatory, since real estate professionals must follow strict fair
housing laws. Any written comment could become evidence in a lawsuit
against you. Keep in mind that online posts can be discovered years
later and linked to you, even if you thought they were anonymous. A good
rule of thumb is to never post anything online you wouldn't want to see
on the front page of your local newspaper.


> **Fire & Brimstone Briar Secret**: Avoid posting on social media about divisive topics which can harm your personal brand, such as politics or religion.


When you create content, ensure it’s something people want to read.
Would you read it yourself? How about your own mother? Would she read
it? If the answer is yes, then you’ve got something valuable to share on
your blog.

## Marketing That Creates Trust

Many people believe that marketing is mainly about promoting the process
of buying or selling a home. However, most of your efforts should be
directed toward raising awareness of you as a results-driven real estate
agent. This requires a multi-layered approach that builds familiarity
and trust. To achieve this, adopt a marketing strategy that emphasizes
building your personal brand.

A simple way to advertise is to turn your car into a mobile billboard by
attaching a magnetic sign. This method builds awareness as you drive
through town, turning your daily routines into passive marketing. People
will recognize you and might even stop to ask a real estate question,
creating opportunities for spontaneous encounters. When you're working a
geographic farm, hosting an open house, or putting up directional signs,
your car becomes a noticeable advertisement. Your clearly marked vehicle
also helps clients identify you when you’re waiting for them at a
showing. When they arrive and see your sign, they feel more at ease.
Make sure the logo and your photo are large enough to be seen from afar,
and ensure every word is clear so no one is tempted to tailgate you just
to jot down your phone number.


As your business grows and you have more capital, you might consider a
full vinyl wrap or purchasing a branded moving truck. A truck with a
full vinyl wrap serves as a large, mobile advertisement. You can offer
the truck to all your clients, including past clients. This benefit is
especially attractive to first-time homebuyers or clients with limited
financial resources. While the truck is in use, it provides free
advertising in that neighborhood. To promote fairness, you might ask
anyone using the truck to fill it with gas when they are finished.
Although the truck will be used for moves only part of the year, its
main benefit comes from parking it in a busy area within your geographic
farm. The truck functions as a mobile billboard and is especially useful
in areas where yard signs or billboards are restricted by local
regulations. You can also use the truck to deliver staging items, clear
clutter from listings, and support promotional activities, such as
handing out pumpkins in the fall. When comparing the yearly costs of a
used moving truck to a billboard of similar size, the truck is often
less expensive and holds its resale value.

You can also build name recognition by providing marketing materials
that prospects or former clients would keep. Consider ordering
refrigerator magnets with your contact information and branding. You
could put a magnet on the refrigerator of each listing and in every
house you help sell. For a more ambitious campaign, you could send out
an annual refrigerator magnet with timely local information, such as the
high school football schedule. While the refrigerator is a fantastic
location, a good secondary spot is the furnace and circuit breaker
panel, where it can be discovered over time. Custom pens with your
contact information are another common and effective promotional item.
They are practical, durable, and help promote your name to prospects and
their friends in ways business cards do not. If you give a pen to a
seller at closing and they later leave it at their bank, your brand is
now in the hands of someone new. Small pads of paper with your branding
also serve a dual purpose. You can hand out the pads to your clients so
they can jot down their impressions of the homes you show them. You can
also use them yourself, and any sheet you hand to someone automatically
contains your contact information.

Another powerful way to build trust is by investing directly in your
community. Billboard advertising, including park bench or bus bench
signs, are an effective way to build brand awareness in a specific
geographic area. While this form of mass advertising takes time to
produce results, it makes sense once your business reaches a particular
scale. Sponsoring a local kids’ sports team or advertising on the back
walls of a school baseball field generates goodwill with parents, who
may be more inclined to use your services.

You can extend this strategy by sponsoring local arts companies and
school activities, especially those with newsletters that reach your
target neighborhood. You can also pursue alternative forms of
advertising that demonstrate civic-mindedness. Adopting a stretch of
highway to keep it free of litter is a free form of advertising that
associates you with a worthy cause. Similarly, many parks seek
benefactors for improvements like benches, trails, and playground
equipment, recognizing donors with a small plaque. These activities
establish your reputation as someone who cares about the local
community, thereby strengthening your brand and building genuine trust.


> **Forever Home Flyer Secret:** Partner with your local animal shelter to feature a “Pet of the Week” on the back of your property flyers. Include a photo of an adoptable animal and a short bio from the shelter. This simple act changes your marketing material into a community service piece. Instead of just another agent with just another listing, you become a friend of dogs everywhere.


While these marketing efforts generate awareness and build goodwill,
your real estate CRM lets you measure the effectiveness of each
strategy. Make sure to fill in the **Referral Source** field within each
new prospect record, referencing how someone heard about you, whether it
was from seeing your moving truck, meeting you at a sponsored community
event, or noticing your sign on a park bench. Over time, this data
reveals which trust-building activities provided the highest returns.

Your CRM can help you manage the logistics of your promotional
activities with task lists. You can use the calendar in your CRM to
track the moving truck schedule. In many cases, you can also piggyback
on the activities you do when promoting your listings to promote
yourself at the same time. Most importantly, your CRM helps you track
and follow up with the network of relationships you establish with local
business owners, coaches, and community leaders. These marketing
strategies build your reputation, and your CRM provides the structure to
turn that reputation into a predictable and profitable pipeline of leads
and deals.

