# Proven Prospecting Methods

> “The best ‘farm’ is a neighborhood where you already have or have had
> several listings. This gives you credibility. Otherwise, you’re simply
> another pretty face on a postcard.”

—Jennifer Allan, *Selling with Soul*

This chapter explains how to systematize the prospecting process. With
your real estate CRM, you'll identify target markets, create checklists,
and develop repeatable strategies that deliver consistent results. The
key to building a sustainable real estate career is converting prospects
into closings. Automation lets you repeat this process for reliable
outcomes. Agents without these tools rely on luck to close deals, which
is not a sustainable approach to running a business.

Once you have identified a target market and built a proven automated
system that delivers results, you can further refine it using your real
estate CRM's goal-tracking features. As you gain experience, you'll be
able to generate higher income from the same effort. All of this is made
possible by your real estate CRM, which organizes, tracks, and holds you
accountable for your successes and setbacks.

## Comparative Market Analysis (CMA)

A **Comparative Market Analysis (CMA)** is a document you prepare to
determine a property's market value by reviewing past sales and current
comparable properties on the market. This is typically done by doing
research using your Multiple Listing Service (MLS). 

The most common use case is creating a CMA as part of your listing
presentation. However, there are other situations where a CMA is also
useful. You might offer to prepare one for a buyer before they make an
offer on a home they are interested in. You could also use a CMA as part
of complementary consulting when speaking with a prospective home seller
in your farm area.

While some software tools can create flashy presentations, I recommend
focusing on a straightforward CMA that is both efficient and accurate.
Let the figures speak for themselves, but use your local knowledge to
tell the story behind them. Your CMA is a moving target. You might
perform a CMA on the same property in January and again in June, and the
results will differ because you'll be using different comparable
properties. The timing of a CMA also affects your analysis of market
trends and current conditions. Selling a home in the dead of January
isn't the same as in June. For these reasons, I suggest creating
low-fluff CMAs. Stick to the facts and the core numbers you use to
calculate your values, and deliver your insights verbally with clarity.

I recommend that you also use the **CMA calculator** in your real estate
CRM. This calculator generates a summary report that can be printed and
emailed. By storing your CMAs in your real estate CRM, you document
exactly what you have provided to your clients and prospects. That way,
if you need to re-evaluate your CMA in 6 months, you will be aware of
precisely what you said earlier. While no valuation stands the test of
time, you should consider neighborhood trends, which can explain any
change in valuation.


> **The Campfire Comp Secret**: Show your mastery of the market by sharing the backstory of each comparable. How long it was listed, what upgrades or issues affected the sale, and why it sold for its final price. Knowing the history of both the property and the local market turns raw data into persuasive expertise.


If you have a listing that hasn't sold, you will likely need to
recommend a price adjustment. The benefit of using the CMA calculator in
your real estate CRM is that you can revisit and update your initial
analysis with new information. If you have gathered showing feedback,
you can provide your client with a service report that summarizes what
the market thinks of your listing and its asking price. A CMA does not
consider the home’s condition or the pink wallpaper in the living room.
Ultimately, the market determines what the house will sell for, and all
you can do is offer your expert guidance.

## Geographic Farming

A **geographic farm** is a specific neighborhood you consider ‘yours’.
You aim to become an expert on everything that happens there and plan to
focus on helping people buy and sell within that neighborhood. How do
you choose a good geographic farm?

Review neighborhood sales and listings in your MLS. Your ideal farm
should have a consistent number of annual sales and enough turnover to
justify your marketing efforts. By calculating the average sale price
and the number of sales per year, you can estimate the real estate
commission potential each neighborhood offers.

Next, review which other real estate agents are active in that
neighborhood. Your MLS will have that information, and you can also get
a good sense by driving around and looking at for-sale signs. This will
help you identify which agents are your competition. Your ideal farm
neighborhood is fragmented, with multiple agents competing for new
listings. If a single agent dominates, it will be harder for you to
break into that market because of brand loyalty to that dominant agent.


> **The Builder Backstory Secret**: Research the original builders of the homes in your geographic farm. Try to get old original floorplans and promotional materials from those original builders. Really get to know the houses, what the shortcomings are, what the most common changes and upgrades are and so forth. Understanding these aspects will give you expertise that no other agent can match, especially when you are preparing CMAs and doing listing presentations.


You should also preview the homes for sale in that neighborhood and take
notes. If builders are actively constructing new homes in the
neighborhood, visit these properties and introduce yourself to the
builder. Home buyers will naturally look at both new and pre-built
homes, so you should understand both the buyer’s and the seller’s
perspectives. Any new listing will compete with other homes, and buyers
often have a more current sense of how competitive a home is relative to
its peers because they see these homes one after the other, usually
minutes apart. Even a slight difference in price, condition, or features
will be noticed. For example, two otherwise identical homes selling for
the same price, but one with a 2-car garage and the other with a 1-car
garage, instantly makes the 1-car garage less competitive. Your ability
to understand these nuances differentiates you from other agents and
makes you more valuable as the listing agent.

Listen to the people in the community. Many communities have an online
presence, so you can easily connect with residents and discover local
trends or concerns. Find out where it is and what people are talking
about. If there is a Homeowners Association (HOA), read the newsletters,
review the financial reports, and attend the annual meetings. Which
schools serve this community, and how do they compare to other schools
in the area? What are the benefits of these schools? Pay attention to
the high school sports teams and which sports are competitive. Attend
some high school basketball games. Volunteer at the local school. Get to
know the teachers. Visit the closest churches and introduce yourself.

Churches are often fertile ground for community activities. This gives
you more ways to meet people and build relationships in your target
neighborhood. Get a copy of their bulletin. Find out whether there is an
opportunity to advertise in it. Find out what is going on and get
involved. Perhaps there is a local Habitat for Humanity home under
construction, and the church is taking part. Or maybe the church is
sponsoring a food drive or a yard sale.

Find out where the local library is. Are there events like story time
and community gatherings? Attending these can connect you with local
families and help you become a recognized part of the community. There
may also be volunteer opportunities that let you rub elbows with
community members. Where are the local parks? Are there summer programs
for kids? Where is the closest day care center? Are there other day care
opportunities, such as at churches and synagogues? Does the local
elementary school offer an after-school program? What about pre-school?

Mass transit can be important for some people. Find out what local
public transportation options are available, including their costs and
schedules. Is it practical for commuting to work? Walkability might be a
factor. How close are neighborhood stores and services, such as
hospitals? What contractors and service companies operate in the area?
Which ones are the best? You will want to build relationships with these
people.

What is the local crime rate? What types of crime are most common? Is
the neighborhood safer than other nearby neighborhoods? How effective
are the local police?

What local newspaper serves the city? If so, read that newspaper. Find
out which reporter covers the beat that includes your neighborhood.
Introduce yourself. Make sure the reporter knows that if they need a
quote on short notice about something happening in that neighborhood or
the real estate market, you would be an excellent source. Be highly
responsive to any requests – free press is the best kind, and it pays to
have connections with the press.

Become acquainted with new developments, shopping, and other changes
that may be on the way. If there are people upset about something that
is going on, find out more.


> **Backroom Briefing Secret:** Attend local city planning and zoning meetings to gain knowledge about what will affect future property values. These meetings will not only allow you to connect with people in the local area but also gives you advanced notice about local changes. This knowledge will make you an indispensable authority able to advise clients on the long-term outlook of the local area.


Find out when local communities are having yard or garage sales and drop
by. If you see someone selling a substantial amount of furniture, ask
whether they are planning to move or helping clean out the home of an
older relative who is downsizing. Yard sales happen all the time, so
this advice is helpful in general, not just during the community yard
sale. You can also sponsor a community garage sale in your geographic
farm each year to build goodwill, increase mindshare, and collect
contact information. The cost is nominal, typically a few vinyl yard
signs you can place strategically, plus postings on Craigslist, Facebook
Marketplace, and other local community websites like NextDoor, as well
as in your Homeowners Association (HOA) newsletter. Coincidentally,
these are advertising locations you already use for your own promotional
activities, so the fit is quite good for you to organize an event like
this.

Find out where the local fire station is located. Is it a volunteer fire
department staffed by neighbors? Many local fire stations host annual
community events. Visit the fire station to learn what is going on
there. Does the city or the parks department host events like a “taste
of” food fair? If so, attend and find out more about local businesses.

It may take you a full year before you are ready to publicly declare
your ‘ownership’ of that neighborhood. When you are ready, walk around,
hang door knockers on every door in the neighborhood, and knock on each
one. Introduce yourself. You will have plenty to talk about thanks to
your careful research. You can talk about the wonderful new elementary
school and whether the high school football team will make the playoffs
again this year, now that their star quarterback has just graduated.

—«◊»—


### Chris Jenkins 

A great way to stay top-of-mind with past clients is to show your
appreciation with a small gift. Real Estate agent Chris Jenkins (Ogden,
UT) finds that his hand-delivered gifts are always appreciated because
they come in the form of Winter Survival Kits. He says the most
effective gifts follow three simple rules:

They are useful enough to keep.

Stay visible at the client’s house.

They are easy to deliver.

He uses his CRM to organize deliveries. Each Salt Lake City survival kit
includes a large bag of ice melt and a thank-you card made by his wife,
decorated with a ribbon and a “Bear-able Winter” message. “I’ve gotten a
lot of positive reactions and referrals from past clients,” he says. “I
chose ice melt as an alternative to branded trinkets because those
trinkets always get thrown out.” Instead of being tossed aside, these
gifts sit on the porch, spark conversations, and remind clients of Chris
every time the homeowner uses the ice melt. These simple yet practical
gifts serve as subtle advertisements and help turn Chris’s clients into
his advocates. The best gifts keep your name in front of clients long
after you drop them off.

—«◊»—

Your first listing in your farm neighborhood will be the most difficult.
That's because you can’t use the pitch you WANT to use, which is that
you are an expert in the neighborhood. So, I recommend that you discount
that first transaction. You need this deal more than any other agent
because it is your launching point, so make sure you get it.

When you send postcards to everyone in a geographic neighborhood, you
can save money by using the **Every Door Direct Mail** (**EDDM**)
service from the US Postal Service. EDDM lets you mail a postcard to
every address on a selected carrier route without individual names or
addresses, lowering postage costs and making neighborhood outreach
simple and consistent.

Canada has a similar program called Neighbourhood Mail. Send postcards
whenever you have a new listing and whenever you sell one. You should
also send one each fall listing all the homes that sold last season and
their prices. People keep postcards like that if they are thinking of
selling.


> **Neighborhood Newcomer Secret:** Monitor property sales in your farm area and personally welcome new homeowners with a small gift and local resource guide. Most agents ignore their buyer clients as soon as they cash their commission check. By being the first friendly face in the neighborhood, you create an immediate relationship.


Watch for signs that a house might soon come on the market. For example,
houses that appear vacant or neglected are a clue. If your neighborhood
has a clubhouse, find out what events it is booked for, such as wedding
receptions, which can provide valuable insights into changes happening
in your neighborhood.

What do you do once you're established in a specific geographic area?
You can never rest on your laurels. Other agents will want “your”
neighborhood. They will use many of the techniques outlined here. Be
persistent year after year, and other agents will look for easier
pickings elsewhere.

## Door Knocking

Door-knocking is a proactive, face-to-face lead-generation strategy in
which an agent goes door-to-door in a specific neighborhood to connect
with homeowners. It helps you get to know neighbors, introduce yourself,
and potentially generate business directly within the local community. 


> **Listen & Learn Secret**: When door knocking you should skip the sales pitch. Introduce yourself and ask, “What is it about this neighborhood that helped you decide to move here?” Listening to their answers builds rapport, disarms homeowners, and gives you authentic language and insights to use in future marketing.


A good pretext for knocking on doors is introducing yourself to the
neighbors when you have a listing in the area. This is especially
effective before an open house. You can say: “You might notice an
unusual number of cars in the area – they will be looking at the
listing. I wanted to give you a heads-up and introduce myself.” Or let
them know about the opportunity to help pick their neighbors by sharing
the listing with a family member or friend. Or, if the price is right,
show them how easy it would be to own a nearby rental house!

Another way to generate interest in your listing is to use your
door-knocking as an opportunity to invite neighbors to an early showing
of the listed home. After all, it is the least you can do given their
patience with all the traffic your crackerjack marketing is generating.

Still, another strategy is to explain that you are providing
complimentary CMAs to neighbors. If there has been significant home
appreciation in that neighborhood, people might be curious about what
their home could sell for in a hot real estate market. A CMA is also
helpful for determining how much equity a homeowner has built in their
home. Equity is the owner’s stake in the property, calculated as the
current market value minus the outstanding loan balance. It grows as
values rise or the mortgage balance falls. Homeowners may want to see
whether they can get out from under Private Mortgage Insurance (PMI) by
building equity above 20% or tap that equity with an additional home
equity loan.

The “Rule of Reciprocity,” introduced by Dr. Robert Cialdini in his book
*Influence*, explains why this works. People feel indebted to those who
have done them a favor or given them a gift, so a free CMA creates
goodwill and opens the door to a conversation. It is an excellent
pretext for collecting an email address and phone number. You already
have their physical address, since you are standing on their doorstep!
Every spring, offer a CMA as part of one of your postal mailings to your
geographic farm. If someone takes you up on it, collect their
information and prepare a professional presentation packet to drop off.
It should look polished and something they will want to keep rather than
casually discard. That way, when it is time to sell their home, they
have something of yours in hand. Since they have shown interest, you
might “touch” these homeowners more often than those who have not. 

To make your door-knocking as efficient as possible, start by knocking
on doors on one side of the street, cross at the corner, and then hit
the other side. Or, if the houses are in a regular rectangular grid,
knock every door all the way around the block, then cross to the next.
Either way, you won’t waste time crossing the street repeatedly.

You can preload your **geographic farm** into your real estate CRM using
valet import. This feature in your CRM lets you load data from external
sources, such as tax records, your MLS, or other third-party lead
sources. With your data preloaded, you'll have the names and addresses
of everyone in the neighborhood at your fingertips. You can then
**access your CRM live on your iPad or smartphone** to pull up this
information, add notes, and include additional contact details, such as
email addresses and phone numbers, as you meet with people. This helps
eliminate the need to transcribe handwritten notes later when you are
back at the office.

You can combine your main purpose with helping others. If your daughter
is in Girl Scouts, taking her around the neighborhood to sell cookies
gives you a chance to say “hi” to everyone. Maybe you’re volunteering
for a school fundraiser or collecting petition signatures for a local
event. If so, choose something non-controversial that everyone can
support.


> **Deeds to Leads Secret:** Promoting good causes for which you volunteer for can be beneficial to your brand, especially when people see you actively participating. It can also be a great way to meet people in a socially friendly way.


**Door hangers** are paper flyers with a cutout that hooks over a
doorknob, allowing them to be left securely at a home without tape. If
no one answers the door, place the flyer on the door handle and move on
to the next house. If someone answers, hand the door hanger to them and
explain why you stopped by. This simple handoff links your introduction
to a physical reminder, helping the homeowner remember you after your
visit.

There are many uses for these door hangers. They can promote a new
listing, an open house, or a home sale, or introduce you. They may also
be part of your awareness campaign, where you visit homeowners and offer
to do a CMA. Each door hanger should include your contact information,
such as a company logo and a portrait photo of yourself. You can have
them pre-printed with blank spaces for you to write in the home address
and the date and time of the open house using a Sharpie marker.

Make sure to include a clear **Call To Action (CTA)** on your door
hanger. A CTA is a marketing term for any instruction that prompts an
immediate response after reading your flyer. Usually, your call to
action asks people to contact you or attend the open house. You don't
want someone to read your door hanger and then toss it.

You could add a **QR code** (short for Quick Response Code) to your door
hanger. A QR code is a two-dimensional barcode that can be quickly read
by a smartphone camera. When someone scans the QR code, they are
directed to a landing page on your website where they can enter their
contact details and property address. This information is automatically
sent to your CRM via an email feed, which triggers your CRM to create a
prospect record, categorize it, and notify you of the new lead.

Alternatively, you can use the call capture phone number built into your
real estate CRM. This is the ideal low-pressure way to automatically
feed information into your real estate CRM.

Beyond formal prospecting, brief personal visits help nurture your
entire sphere of influence. These visits are sometimes called **drive-by
visits**. In an age flooded with digital messages, a quick in-person
visit stands out as a powerful way to make an impression. Dropping by a
past client’s home on their closing anniversary is a memorable way to
celebrate with them and see how they are enjoying their home. You can
also create other social reasons for these visits, such as dropping off
small pumpkins for Halloween or tiny USA flags for the Fourth of July.
These short interactions are based on goodwill, not sales.

—«◊»—


### Colleen MacCallum 

Building a steady stream of leads begins with consistent prospecting.
Many new agents struggle with this consistency because they don’t have a
structure to manage leads and for follow-up. Colleen MacCallum, Co-owner
of EXIT Right Realty, is an agent who combines her old-school methods
with new-school technology. “I’m very aggressive: I like to door-knock
and cold-call. My goal is to get a certain number of appointments into
my CRM, and I just keep calling until I hit that target,” she says.
Looking back, she wishes she’d started using a CRM sooner. Many new
agents hesitate to start using a CRM because it feels like “one more
thing to learn.”

Colleen admits she felt the same way early on, but now sees that
delaying it only made things more complicated. “A good CRM makes it so
much easier just to sit down and get to work calling every day. It keeps
me focused and accountable.” But she warns against automating too much
of your work. “People want to see the person behind the call, not a
robot, so personal touches will always be important,” she says. She also
advises against constraining yourself in an overly complex system. “You
shouldn’t spend more time learning a tool than using it,” she says,
“Pick something that helps you stay organized without adding stress.”
Prospecting should be part of our daily routine. If you find it
stressful, you’ll stop doing it. Use a simple system to track your work,
but make sure you stay personable when you do follow up.

—«◊»—

This strategy is vital for building a geographic farm. When you're in
the neighborhood for an open house, it's a great chance to visit a
nearby past client. Regularly showing up in the area helps you build a
visible, consistent presence, letting residents know you're the local
expert. These quick, face-to-face visits foster familiarity and trust,
turning you from just another agent into a familiar, welcome face in the
community.

For high-value prospects such as FSBOs and expired listings, a drive-by
visit is a powerful option. Dropping off a pre-listing packet in person
demonstrates a level of effort that a phone call or email cannot match.

Visiting the day before your listing appointment to drop off marketing
materials helps build rapport and gives you a firsthand look at the
property. This personal touch shows you are a serious professional
willing to invest time early in the property.

If you do not live in your target farm neighborhood, consider building a
network of local friends who do. Buying or selling a home is a
significant decision, and most people spend several months contemplating
it. They might mention to neighbors that their current home feels too
large now that the kids are in college. If you can spot these early
signs, you can support the decision-making process by offering a
no-obligation consultation. Reaching people early is always to your
advantage. This can help you avoid direct competition with other agents
for the listing.

## Prospecting Absentee Owners

One often-overlooked source of listings is prospecting absentee owners.
An **absentee owner** is someone who owns a property but doesn't live
there. You can find these prospects by checking public property tax
records or buying lists from a lead service. Because they don't reside
there, the property is likely rented or vacant, creating a unique
opportunity. These owners are often more willing to sell than typical
homeowners because they may lack a strong emotional attachment to the
property and face the challenges of managing it from afar. For them, the
house is an investment, and selling becomes a practical option if it's
no longer convenient or profitable.


> **The Haunted House Secret**: When contacting absentee owners, research the property’s history and status. By knowing if it’s a rental, vacant, or has been on the market before you contact them allows you to provide customized advice which matches their unique situation.


You can use your CRM's valet import feature to upload your list of
absentee owners into your prospects database. This lets you import fresh
absentee owner leads weekly with a single click. You can then nurture
these leads with a scheduled drip campaign of printed letters,
customizing the content to showcase your services. Additionally, you can
place these leads in a follow-up touch cycle and reach out to the
homeowners via text or voice. These leads usually won't have an email
address, as tax information may not be publicly available.

One nuance to keep in mind is that you should use the prospects
database, not the contacts database, for your leads. These people are
strangers and therefore do not belong in your contacts database. The
prospects database also allows you to store both a property address and
a mailing address. Since the homeowner does not reside on the property,
having two addresses per property is essential. By recording both
addresses, you can print mailing labels using the mailing address and
use the property address as a mail merge variable when crafting your
letters.

You might highlight your ability to manage the sale of a rental
property. Tenant-occupied properties can be harder to show and may have
condition issues. To address this, you could promote your services in
finding cash buyers, investors, or flippers who are less likely to be
deterred by these limitations. Your problem-solving skills help sellers
and distinguish you from other agents. This can be the key distinction
that convinces an owner to choose you, as it demonstrates that you
provide customized solutions rather than just a standard MLS listing.

If the property is vacant, you could offer to find a new tenant or even
handle long-term rental management. These two services often complement
each other when buying and selling homes. The MLS can list properties
for rent as well as for sale. While you would earn a higher commission
from selling a property, individual circumstances or economic conditions
may make finding a tenant a better option. Your ability to provide a
full range of services also makes you a better fit for investor and
flipper clients. It also gives you more options when economic conditions
make selling difficult but renting easier. 

## Turning Expired Listings into New Clients

**Expired listings** are properties listed for sale that didn't sell
before the listing agreement expired. If the house doesn't sell within
the specified timeframe, the seller will likely blame the listing agent.
The seller's initial response is usually to fire that agent and hire
someone new. Expired listings create a great opportunity in slow real
estate markets.

The simplest way to identify expired listings is to subscribe to a
service that provides a daily or weekly CSV file of expired listings.
You can then import the file into your real estate CRM using its valet
import feature. You can also use your MLS to view expired listings;
however, some MLSs have restrictions on this.

Working an expired listing the day it comes off the market can be tough,
as the seller is often bombarded with calls from other agents. The
homeowner is also likely upset and distrustful after their home didn't
sell. Instead of jumping into the initial rush, wait a week or two. This
delay gives the seller time to process their frustration and become more
open to a new, well-thought-out plan. Use this time to research the
property, understand why it didn't sell, and develop a careful strategy
that pinpoints the problem so you can suggest a solution.

Find out who the previous listing agent was. Is there something about
that agent that caused them to fail? There are many ways an agent can
fall short. Maybe the listing agent used poor photos, a weak
description, was inexperienced, or didn't understand the neighborhood.
The previous agent probably failed to communicate effectively with the
seller and did little to promote the home beyond the MLS listing. Drive
by and take a few photos of the property. Is there something about how
the property appears from the outside that explains why it didn't sell?

With this information in hand, you are ready to create your marketing
plan. While your first instinct might be to call, remember this seller
is frustrated and receiving many calls from other agents. Sending a
printed letter is a more professional way to stand out from the noise
and build the credibility needed to deepen your relationship. Write a
letter that hints at your analysis and recommended course of action, and
ask for an in-person meeting to explain how you would market the home if
you were the listing agent.

Remember, the goal of your letter is to secure a listing appointment.
Don’t reveal everything in your letter. Instead, provide enough
information so the seller sees you have a tailored plan for their home
and are eager to get started. The best way to turn a prospect into a
client is through a direct face-to-face meeting.


> **Give Gratitude Secret**: After meeting a potential client, follow up the same day with a personal note referencing your conversation. Acting fast will keep you at the top of their mind.


Most of the expired listings you handle will require a very similar
analysis and recommendation. Therefore, I recommend creating a reusable
letter template in your real estate CRM to save time. Use mail merge
variables for the parts that change each time, such as the property
photo, the seller’s name, and the property address. Before printing,
make one final customization to the letter template. This allows you to
remove irrelevant passages or adjust the wording, ensuring each letter
feels slightly different. Your seller should perceive that you have
provided a unique analysis and recommendation tailored specifically to
them.

By focusing on a personalized approach, you're setting yourself apart
from other agents, which is why you'll succeed where they don't. Mention
that you're already working with several buyers interested in the
neighborhood, leveraging your deep roots in the community. If you
believe home staging was where the last agent went wrong, you could
highlight your skills in that area as well.


While most agents will be calling, you should step up your game. Make
your phone call, but instead of delivering your pitch, say you will be
in the neighborhood, would like to drop off a pre-listing packet, and
would like to confirm that someone is at home. Your packet should be in
a large envelope with the seller’s name and address, along with your
return address. 

Include a small version of the photo you took of the property. The
easiest way is to use a Dymo Label Printer to print two labels for the
envelope’s outside. One label should have your return address, and the
other should include the property address along with a photo of the
house. That photo proves you are not sending a generic form letter. It
shows you have personally visited the property and know what you are
talking about! Include your letter and business card inside the
envelope. You should also add some biographical information about
yourself. While you could include glossy details in your general
marketing efforts, that may not work well for you. Remember, the last
agent probably had a glossy brochure too, and they failed.

Expired listings take time to incubate, so an initial phone call and a
drive-by are a good start. However, persistence is key. Use your real
estate CRM to schedule a recurring touch cycle with the seller every 1-2
weeks. Each touch could be a call, text, or drive-by. The main point is
to be consistent. If your CRM includes a letter sequence specifically
for expired listings, use it. You can also use your CRM to print
envelopes or labels and mail-merge those letters. The more persistent
and consistent you are, the better your chances. Sellers may have had a
bad impression of agents from their last experience. Each time you knock
on their door, call, or send a letter, you're showing them how hard you
work for your commissions. The more persistent you are, the stronger
your case for being their new agent.

## Approaching For Sale By Owners (FSBOs)

When a homeowner decides to sell their home on their own, they may
believe they can save money by handling the sale themselves. Your value
proposition is to sell the house quickly, for the highest possible
price, and with minimal hassle. This isn’t just a sales pitch; data
supports it. Homes sold with an agent’s help consistently fetch higher
prices than those sold by owners[21]. This price gap can even exceed the
entire commission, meaning there’s a good chance the seller will end up
with more money and less stress by hiring you.


> **The Gift Horse Gambit**: Unlike an open house buyer who expects a direct follow-up, an FSBO seller is actively trying to avoid agents. Your first move shouldn't be to ask for their business; it must be to demonstrate your value. When you visit an FSBO in person, bring something immediately helpful, like a one-page neighborhood market update or a checklist of common seller mistakes, without asking for anything in return.


Selling a home involves a tremendous amount of work, and the homeowner
rarely fully understands everything that goes into going from “for sale”
to “sold.” Setting the price is the first hurdle. Thanks to your
expertise in local market conditions and MLS data, you are uniquely
qualified to set a competitive price. Homeowners do not have access to
that same information[22]. They are just as likely to underprice the
home as overprice it. Both situations are less than ideal. In the first
case, they leave money on the table, and in the second, the house will
not sell.

Assuming the homeowner has cleared that first hurdle, they then need to
promote the home. Once again, a realtor has an advantage with access to
the MLS.

Assuming the homeowner generates interest with a yard sign, the next
challenge is to be available to schedule and show the home. Homeowners
are often the worst people to show their own homes, as they lack a
neutral perspective and are unlikely to have decluttered and
depersonalized beforehand.

There is also a real concern that the buyer has not been prequalified or
vetted, or worse, might be a scammer. A homeowner might also worry about
personal safety or theft of their belongings. A real estate agent will
show a home only to vetted, pre-qualified buyers and will do so under
strict supervision.

It's no surprise that an estimated 20% to 30% of FSBO sellers eventually
hire an agent after encountering these realities[23]. In real estate
coaching circles, a common guideline is that many FSBOs give up around
the five-week mark[24]. Your follow-up plan, orchestrated by your CRM,
provides a roadmap for converting FSBOs into clients. The process
usually takes several weeks and multiple interactions with the
homeowner. Your goal is not a quick appointment, but to counter their
impression that you are not worth your commission by consistently being
a resource, not a salesperson.

While your long-term goal is the full listing, a highly effective
intermediate strategy is to offer a different kind of solution during
your scheduled follow-up calls and in your printed letters. Many FSBOs
who refuse to pay a 6% commission will gladly pay 3% if you bring them a
qualified buyer. Present this as a low-risk option. This approach
directly addresses their main concern about saving money while also
solving their biggest problem: finding a serious, pre-qualified buyer.
It’s a great way to get your foot in the door, show your value, and
build trust that can lead to a full listing.


> **Stagger, Don’t Stack Secret:** When you send a series of letters or postcards in the postal mail, send each letter at least 1 week apart. Otherwise, you run the risk of one piece arriving alongside the other. USPS does not deliver on Sundays or federal holidays, and delivery times can vary for reasons outside your control.


Success with FSBOs requires a consistent, long-term nurturing plan.
After your initial contact, use your CRM to start a time-released
sequence of printed letters. This print-first approach is often
necessary for two main reasons. First, because you will always have
their physical address, mailing a letter or dropping it off are your
most reliable ways to reach them. Second, a printed letter offers a
non-confrontational way to demonstrate your value and professionalism,
helping you earn the right to a phone call with a seller who is actively
trying to avoid agents.

Choose one day each week to complete your follow-up tasks. Your real
estate CRM automatically sequences which letters to send, letting you
print them with matching mailing labels in just a few clicks. While
other agents make a single call and then disappear, your system ensures
a professional touchpoint arrives week after week. When the seller’s
motivation wanes, your letter is on their counter. Success with FSBOs
comes from a disciplined system, not a hard sell. By combining a helpful
first impression with patient, systematic follow-up, you become the
clear expert to call when they are ready for professional help.

## Reverse Prospecting

**Reverse prospecting** is a powerful, proactive feature within your
Multiple Listing Service (MLS) that serves as a matchmaking tool for
your listings. Instead of passively waiting for buyer agents to discover
your property, you can identify agents whose clients have saved searches
that match your listing’s criteria. The MLS cross-references your
property’s details, such as price, location, and number of bedrooms,
with the specific search parameters of active buyers. The system then
generates a list of these buyers’ agents, giving you an inside track on
the most likely pool of interested parties.

While the MLS identifies the opportunity, your real estate CRM serves as
the command center where you execute the plan. The first step is to
import this list of agents from your MLS into your CRM using the CRM’s
import feature. You can assign a category to those records during the
data load, such as “123 Main Reverse Prospecting.” This segmentation is
essential for targeted follow-up.

Your outreach should be precise and convey a sense of early access,
fostering a collaborative relationship. Your aim is to position yourself
as a helpful resource rather than just another agent pushing a property.
For example, you might start with a phone call or a targeted text
message sent directly from your CRM.

“Hi Sally, this is Jack Smith from RE/MAX. I saw that one of your
clients has a saved search that flagged my new listing at 123 Main
Street. I am about to add this listing to the MLS and wanted to give you
an early heads-up before it gets more exposure. Call me if you have any
questions. I'm attaching a flyer so you can see if this new listing
might be a good match for your client.”

Experienced agents who systematize this process report a significantly
higher contact-to-showing conversion rate because they have an active,
pre-qualified buyer already searching for homes that match your listing.

You can also use reverse prospecting after a price reduction. A price
change might suddenly place your listing within the saved search
criteria of a new group of buyers. By rerunning the reverse prospect
search, you can notify their agents immediately, creating a fresh wave
of interest. By combining the strategic insights from your MLS with the
organizational strength of your CRM, you can target the exact group of
agents most likely to be interested in your new listing. This not only
increases the chances of a sale but also pre-loads that interest early
in the listing process, boosting the likelihood of a faster sale or even
a bidding war.

## Working with New Home Builders

Working with home builders can generate recurring revenue, as they may
list multiple properties over time. You can collaborate with builders in
various ways, each with its own benefits and responsibilities. These
might include providing services to buyers or serving as a listing agent
for one or more of their homes.

Start by introducing yourself to local builders and visiting their model
homes to get familiar with the homes they offer. Then, ask whether the
builder will honor your commission if you bring a buyer. If they agree,
send an introductory email about any client you refer before that client
visits any builder property. This creates a time-stamped record of your
involvement and protects your commission. Always follow the builder’s
registration policies to ensure you’re properly credited for the sale.

Building a closer relationship with a builder might also involve a
co-marketing partnership to help sell the builder’s new homes. Builders
often have an ideal customer profile for each development. You might not
need to generate entirely new leads, as many of those ideal clients
could already be in your database. You can identify and segment them
using categories such as “First-Time Homebuyer” or “Downsizing.” After
identifying these clients, you can launch a targeted email campaign to
that group. Importantly, the campaign's call to action should direct
prospects back to you, not directly to the builder.

This could be a link to a **lead-capture form** on your website that
adds new prospects to your CRM. Many broker-provided websites include a
basic “contact me” form that serves this purpose. Additionally, some CRM
vendors offer a standalone lead-capture web page you can link to
directly, eliminating the need for a custom website.

When a prospect responds, you can personally introduce them to the
builder’s sales team. This way, the builder receives a qualified lead,
and you remain documented as the buy-side agent, ensuring your
commission is protected.

Another way to foster a partnership is to provide builders with
actionable market feedback. Prospective buyers' opinions are invaluable
to developers, helping them adjust pricing, finishes, and future floor
plans. During open houses or showings, use your CRM to systematically
document visitor feedback. Record comments on the layout, price, and
specific features. Afterwards, compile this data into a professional
service report for the builder. Providing this data-driven insight
elevates you from a sales agent to a trusted consultant, making you an
indispensable partner.

Offering to host an open house can be a great opportunity for builders
without a sales team. During the event, use your CRM’s online sign-in
form to capture visitor information. As leads are captured, your system
sends you instant notifications for quick follow-up. You can then
nurture their interest by assigning visitors to a drip email campaign
with more details about the development. Both you and the builder
benefit. You gain a new source of leads, and the builder reduces
staffing costs. You can also work directly for a local builder as their
selling agent. Some smaller builders may offer this role on a commission
basis, allowing you to keep your existing book of business. Larger
builders might hire you on a salary.

You should also build relationships with contractors who specialize in
home improvements, such as finishing basements and remodeling. You might
be working with a buyer looking to purchase a property that needs
updates. Having a trusted general contractor on your side allows you to
bring them in to help your buyer understand which improvements are
practical and to provide a rough cost estimate. These partnerships can
help you close a deal that might otherwise be overlooked and demonstrate
your value as an agent who leverages vendor relationships to solve
client problems.

