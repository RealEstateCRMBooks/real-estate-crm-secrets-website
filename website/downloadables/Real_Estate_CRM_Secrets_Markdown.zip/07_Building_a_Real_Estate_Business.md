# Building a Real Estate Business

> “Forging new relationships makes the world go round. When you meet new
> people, you make connections that can lead to all kinds of future
> breakthroughs. Stop trying to “sell” people on using your services,
> rather, focus on forging a relationship and providing value to that
> relationship. Even when it’s uncomfortable, reach out and introduce
> yourself to new people… try knocking on 100 doors a day and simply say
> “Hi, I’m Dave. I’m a broker with XYZ. I wanted to meet you face to
> face and wondered if you’d mind if I emailed you recent real estate
> activity on occasion?” The worst they can say is “no.” Fortunately,
> many won’t.”

— Dave Crumby, Lani Rosales, Martin Streicher: *REAL*

Being a real estate agent can be a highly rewarding career. You help
someone find their dream home. Seeing that look on their face when you
hand them the keys at closing is priceless. If you do your job right,
your client won’t even realize how tough the process was or how many
times the deal nearly fell apart. Making the process of buying and
selling a home smooth is why you get paid.

But before you can close that first deal, you must first master the many
intricacies of real estate sales. As a new agent, you have a lot of
energy and some book knowledge, but lack practical experience. To reach
the point of handing over those keys and earning a commission, you need
to master the art of relationship building and careful organization.
This starts with developing daily habits, systems, and conversational
skills necessary to create a pipeline of future clients. While
understanding contracts and negotiations is essential, your initial
success depends on embracing the fundamental business tasks that happen
before you ever write a single offer. This chapter guides you through
building that vital foundation.

## Your Job as a Real Estate Agent

Most people think a real estate agent’s job is helping someone buy or
sell a home, but that’s only a small part of the entire sales process.
Before you can assist anyone, you must first be hired. The most
important part of your job is meeting new people and building
relationships. Set a daily goal for the number of new people you meet,
and give yourself credit when you learn their names and collect their
contact information. Once you do, make sure to enter that information
into your CRM.

Your ability to build trust is the first step in the deal lifecycle.
Think of the deal lifecycle as the sequence of stages a transaction goes
through. It starts with initial contact and qualification, moves through
agreement and active home search or listing preparation, and concludes
with negotiation, escrow, and closing. The lifecycle provides structure
to your daily work because each stage naturally flows to the next,
establishing the right rhythm and messaging. 

To stay organized, your CRM allows you to split people into two groups.
The first group, your prospects, consists of individuals who are
directly interested in buying or selling. These leads should be entered
into your **prospects database** for active follow-up via phone calls,
SMS, and scheduled email sequences. Although it would be ideal if these
people responded immediately, that’s not always the case. Some may take
weeks or even months before deciding to hire you.

Your CRM is crucial for managing this process, offering follow-up
reminders for your direct calls, and support for automatically sending
educational drip emails for long-term nurturing. **Drip emails** are
prewritten emails or printed letters sent to a single contact over time
to educate, nurture, and encourage action. They are sent at scheduled
intervals rather than all at once. The term comes from drip irrigation,
where plants receive slow, steady watering instead of a flood, so the
recipient gets a consistent stream of value that keeps you top of mind
without overwhelming their inbox.


The second group is your **contacts database**, which includes people
who don't actively need your services. These contacts are part of your
warm market, also known as your **sphere of influence**. A good way to
describe these people is that they would recognize your name or face.
These would be friends, neighbors, relatives, and past clients. These
are people who already know you, trust you, and recognize your name.

Your contacts database also includes other real estate agents, as well
as vendors such as home inspectors, loan officers, and tradespeople like
plumbers and electricians. These are the people you rely on to help
close a deal, and for this reason, they often have an interest in
assisting you with closing any deal. However, they are usually not
buyers or sellers themselves.

For people in your sphere of influence, your best approach is to
maintain and strengthen your existing relationships. As their friend and
a real estate professional, it’s natural for them to turn to you first
when they’re ready to buy or sell. Don’t focus on real estate topics
unless they bring them up. Your friends are your most valuable asset,
offering both direct business and referral opportunities.


To build meaningful connections, listen carefully and remember details.
When you talk to someone, keep your CRM open so you can jot down
**notes** about their interests, spouse’s name, children’s names,
birthdays, and favorite sports team. If someone mentions they love
mid-century modern homes, note it. When you call them in 90 days, you
can ask how their favorite team is doing in the playoffs or mention that
a special home in their preferred style just became available. These
details help you have smarter conversations and show you genuinely care.

Success requires spending time on all aspects of your business. You will
work with current clients, but you also need to set aside time to
attract new prospects and nurture your sphere of influence. If you
neglect prospects, another agent will snatch them. If you forget to call
your friends on their birthday, they might take their business elsewhere
when they need a real estate agent. I recommend scheduling time each day
in your calendar for making outgoing calls. Use tasks in your CRM to
organize your follow-up. Take notes during your calls, and schedule your
next contact before hanging up.

Don’t take your friends for granted—review each contact record at least
once a year by calling, emailing, or sending a physical Christmas card.
Your main goal is to build mindshare. This mindshare isn’t created by
“selling” to them but by being a consistent, genuine presence in their
lives. When someone asks a friend of yours for the name of a real estate
agent, you want that friend to immediately recommend you because you are
a friend they trust, who also happens to be a real estate expert.

The trust you establish within your sphere of influence is a key
building block of your real estate career. As you gain experience, you
should expect roughly half of your income to come from referrals and
past clients. The National Association of Realtors (NAR) reports that
66% of home sellers either hired their previous agent or found one
through a referral[1]. Of course, for new agents, this percentage will
be much lower. You can’t rely on repeat business from someone until
after you've first done that first deal with them.

By establishing these foundational habits of consistent outreach and
meticulous record-keeping, you elevate your CRM from a basic address
book to a powerful business tool. This system enables you to manage both
active prospects and your long-term network with professionalism and
care, ensuring no opportunity is missed. Your disciplined approach
builds the trust necessary for a referral-based business and provides
the structure to turn your initial efforts into a predictable,
sustainable income.

##  Surviving Your First Year

Your first year as a new agent involves building the foundation of your
business. This begins with obtaining a real estate license and choosing
a brokerage to join. After selecting a firm, discuss your anticipated
expenses with your broker. A broker is the professional who holds the
advanced license necessary to own the firm and supervise its agents.
They are legally responsible for every transaction the brokerage
manages.

Unlike traditional jobs, real estate agents work entirely on commission.
You won’t receive a salary, hourly wage, or regular paycheck. Your
income depends solely on closed transactions. This means you could work
many hours and earn nothing if a deal falls through. You are only paid
when a property successfully transfers ownership and closes. Create a
spreadsheet of your projected costs for that first year. Running out of
cash is the biggest reason many real estate agents end their careers
early[2]. Some expenses will vary depending on how much business you do.
Still, you should be able to estimate a rough figure based on
information from your broker and other real estate agents in the office.

After calculating your expenses, determine how many homes you need to
sell to reach the break-even point. Use the real estate commission
calculator in your CRM to find your net commission after the split (the
percentage shared with your brokerage), franchise fee (if your broker is
part of a national brand), and other deductions for a typical sale.
Expect a delay between your expenses and income, so ensure you have
enough cash on hand to cover several months before commissions start
arriving. Keep a close watch on your costs.

If there is a more affordable way to do things, start with that approach
first. You can always spend more money later, but right now, you don't
know what you need. Many expenses should be avoided in your first year.

A custom website won’t generate immediate income and shouldn't be your
top priority. For your first year, focus on using the website your
broker provides.

Also, wait before paying for leads from lead services. Instead, focus
on leads from your own prospecting efforts and your sphere of influence.
As you gain experience and become better at converting leads into
clients, you can consider paid lead services like Zillow.


> **Slow Start Secret**: For real estate agents there is a delay between work and payment. New agents will typically see their first commission check arrive 3-6 months after starting. Because of this time lag new agents should keep their expenses lean until closing a few deals.


Your next step is to sign up for a free trial of a real estate CRM,
which serves as the command center for your business. It’s easy to feel
overwhelmed by the options, so focus on a vendor that offers a
no-obligation free trial, an affordable price, and either month-to-month
billing or a prorated refund policy. A prorated refund removes the risk
of a long-term commitment while still allowing you to get a lower annual
price. This way, you can switch vendors whenever you want. Steer clear
of vendors that require a credit card to sign up for the free trial or
that mandate a one-year commitment.

Since you're on a budget, avoid choosing an expensive vendor. For your
needs, an affordable real estate-specific CRM is exactly what you need.
Buying an expensive one won’t benefit you and will only drain your
budget. You also don't need a system with complex features you won't
use. That will only slow you down.

This chapter describes the “core” features that all CRMs share, and also
explains the “real estate-specific” features you'll need to get your job
done. A generic CRM simply won’t work for real estate, as the real
estate business is highly unique.

Finally, you should select a CRM that’s easy to use and offers live
phone support. Since you're just starting out, you'll have many
questions, and the last thing you want is to wait for email responses.
The biggest mistake you can make is waiting until you have a client to
get a CRM. Your CRM will help you with prospecting, and you need it to
start building a prospecting pipeline from day one.

—«◊»—


### Samantha Clement

When you’re starting in real estate, every tool you pay for needs to
deliver real value. The goal is to find the system that saves you time
and helps you grow without costing you too much. Samantha Clement, a
Real Estate Agent in Okotoks, Alberta, first started her business by
using the free contacts program that came with her computer. That worked
fine at first, but as her client base grew, she quickly hit limits.
While the benefit of her system was its low cost, the downsides were the
inability to handle reminders, scheduling, or tracking listings and
commissions.

Like many new agents, Samantha hesitated to invest in a new system
because of cost and complexity. “A free trial is important,” she says.
“You need enough time to see if a system really fits your business
before committing the capital.” By testing different options, she
discovered that the price of a CRM does not necessarily represent how
useful it can be. What was most important was finding tools that she
could quickly understand and use. “Simplicity was key for me. If a
system took too long to figure out, that was time I wasn’t spending with
clients,” she says. Her advice to other new agents: Start with free or
low-cost tools, take advantage of extended trials, and find systems that
maximize your time with clients.

Samantha also came to appreciate the importance of responsive technical
support. At the same time, she found that importing her client records
was easy. She has some questions about configuring her CRM for the
Canadian market. That’s where phone support became essential: “I only
called support a couple of times, and they always talked me through
whatever issue I had,” she shares.

—«◊»—

Once you have your CRM, your first task is to develop your most
important asset: your contacts database.

If you have a smartphone, you can set up synchronization so your phone’s
address book and calendar sync with your CRM. Also, review the address
books in all your email accounts and export the data from each. Be sure
to include relatives, neighbors, friends, and anyone else you can think
of. Your first client is likely in this database.

Since your CRM’s database is essential for your livelihood, ask your CRM
vendor a few practical questions early on. How often do you back up my
data, and how long do you keep those backups? Can I export my data at
any time in a standard format, such as CSV? If I accidentally delete a
record, can I restore it myself, or can the technical support team
restore it for me? Is there a way to review a change log to see who made
what changes and when?


> **The Database Ditch Secret:** Export your entire database at least once a year. Accidents happen, and a backup is a good safety step. Also, someday you may want to switch CRM vendors and will undoubtedly want to take your database with you. Keeping a backup of your database gives you peace of mind.


With your CRM in place, success now depends on your daily habits. A
common challenge for agents is the unstructured nature of real estate
sales. You are no longer accountable to a boss who watches when you
arrive in the morning or leave in the evening. But you do have a boss:
you. You are just shortchanging your chances of success if you put in
less than a full effort. Block out time in your calendar each day for
activities like prospecting, doing CMAs, and door-knocking.
Door-knocking is a face-to-face prospecting activity in which you walk a
defined area, knock on doors, and start brief, courteous conversations
at the doorstep to introduce yourself, listen, and learn.

Your real estate CRM, MLS, and other brokerage software are tools that
will help you work more efficiently, and each of these organizations
offers free training. Take advantage of that training to harness the key
features these systems provide. Hold yourself accountable and stick to
your scheduled activities. It's tempting to skip activities you dislike.
Instead, I recommend scheduling the tasks you dread for early morning
and completing them right away.

Once your contacts database is populated and you've blocked out your
time, start reaching out to people in your network to inform them about
your new real estate career. Pace yourself and aim to make a certain
number of calls each day. A phone call is more effective than an email
because talking to someone may prompt them to mention someone they know
who is interested in buying or selling, or reveal that they are looking
to do so themselves. You can also ask friends and family to act as your
scouts and notify you if they hear of anyone who might need an agent.

The easiest way to do this is to **sort your database** by last contact
date. This arranges your contacts so that those you spoke with the
longest ago are listed first, and the most recent contacts are last. Use
the click-to-dial feature of your CRM to call the people at the top of
the list. **Click-to-dial** allows you to click a link on your computer
to call someone from your mobile phone. Take notes and update the last
contact date. If you feel the contact is high value, you can schedule a
follow-up. This way, when you hang up, that contact record drops to the
bottom of your list. If you do this daily, you'll eventually reach
everyone. Don’t forget to record any disconnected phone numbers.

You should also take the opportunity to add a few categories to each
contact record to help you keep everyone organized. **Categories** serve
as tags for each contact record. Common categories include “Friend”,
“Family”, “Plumber”, “Agent”, “Buyer”, “Seller”, “Church”, and so on.
Categories allow you to operate on a group of people at once, such as
sending a bulk email. They also help you quickly find someone in a
specific category, like a “Plumber.”

If you feel someone isn’t worth a phone call, consider adding them to
the “NoLead” category to indicate they are not a potential client. For
example, if you don’t plan to call your dentist to inform them of your
career change, you could add the “Dentist” and “NoLead” categories to
that contact record.

As a salesperson, words are essential tools for your role. The words you
choose shape how prospects and clients respond and can impact your
success in winning clients and closing deals. Over time, choosing the
right words will become second nature. But when you're just starting
out, the best way to learn these subtle word choices is to spend time
with an experienced agent. Watch their word choices, pauses, eye
contact, and gestures. While you can develop these skills on your own,
observing others will help you learn much faster.

For example, while most people consider “house” and “home” as synonyms,
an experienced real estate agent understands that “home” conveys a warm
feeling to buyers. For a seller, use the less emotional word “house,”
since the last thing you want is for them to get emotional about selling
the place where they raised their family. Similarly, you should refer to
the listing agreement as “paperwork.” Although it is technically a
“contract,” that word can cause concern, whereas “paperwork” sounds less
intimidating.

One of the most challenging and exciting parts of a real estate agent’s
job is handling objections from a difficult or hesitant prospect. It’s
hard to predict how a conversation will unfold, and you may encounter
objections or questions you’ve never considered before.

I recommend gradually building your experience. Find a busy agent in
your office who is willing to hire you for listing tasks, such as
hosting open houses, creating flyers, and performing CMAs. This way,
even if you don’t have any listings yet, you can steadily gain hands-on
experience. Spending time with buyers at an open house sharpens your
conversational sales skills. Door-knock the neighborhood before an open
house to get more face time with residents and learn more about that
neighborhood. You build your experience step by step through small,
manageable activities. Every hour you invest this way makes you better
at your job.

Another tool that you should use are real estate scripts. You may have
heard of Malcolm Gladwell’s “10,000-Hour Rule” from his book *Outliers*,
which suggests it takes about 10,000 hours of dedicated practice to
become an expert at something. As a new agent, you do not have those
hours yet. Scripts provide a way to leverage the experience and
knowledge of agents who have already put in their 10,000 hours. They
serve as a crucial bridge, allowing you to use language that has been
tested and proven effective while you are still building your own
expertise through practice. You can find scripts from experienced agents
in your office, your broker, or online.

Memorize these scripts, especially for face-to-face prospecting
interactions like door knocking and open houses. Your goal is to not
sound robotic and to master the script so you come across as natural and
persuasive. This preparation helps you avoid struggling for words and
instead focus on actively listening to your prospect[3].

You will need to work harder than an experienced agent because you'll
make mistakes and learn from them, which takes time. A more seasoned
agent also has a client base, a reputation, and brand recognition to
depend on. Working with new leads requires more effort than with past
clients, as you first need to sell yourself and then the home. A good
rule of thumb is that you'll work twice as hard with strangers as you
would with a past client or friend. Your CRM can accelerate your growth
by helping you with follow-up. As you build your reputation, your
contacts database will also grow, and your CRM can help you maintain
relationships with people likely to refer your services. Before you know
it, you'll be the experienced agent!

A common strategy for new agents is to observe and imitate the most
successful agent in the office. You will gain a lot by adopting their
proven strategies, but keep in mind that some actions of a successful
agent may not be a perfect fit for a new agent. Most new agents focus on
buyers rather than sellers because it is typically easier to convince a
buyer to hire a new agent than to convince someone selling their home to
take a chance on an agent with an unproven track record. More seasoned
agents usually prefer listings, as they are considerably less work and
tend to have a higher rate of success than buyers.


> **Borrowed Buyer Secret:** Ask a more experienced agent in your office if they have any buyer clients they could send your way. You would pay the other agent a referral fee, so both of you make money when the deal closes. That way, the more experienced agent can focus on more profitable clients, like listings.


You can leverage these differing preferences. You could offer to host
open houses for more experienced agents in your office. Use the
electronic open house sign-in form built into your real estate CRM to
avoid manual data entry. Visitors would fill out the **open house form**
on your iPad, allowing you to collect their name, phone number, email
address, and whether they are already working with another agent. There
are numerous ways to structure this so it is financially beneficial for
both you and the other agent. You could represent the buy side of the
transaction, with the listing agent representing the sell side. Or, you
could work out a fixed fee for your services.

You can offer additional services for a small fee. Spending time on
these tasks helps you gain experience and receive feedback on your work.
You might create flyers, take photos of homes, install lockboxes and
yard signs, make copies of keys, and more. As you complete these tasks,
you'll become more efficient with your time, especially in managing
travel time outside the office. Planning your trips to maximize
productivity will boost your earning potential.

One of the most important skills you can learn right away is how to
quickly prepare an accurate **Comparative Market Analysis (CMA)** using
your Multiple Listing Service (MLS). A CMA is an essential report that
helps you determine a property’s market value by reviewing past sales,
current comparable properties, and even homes that did not sell. To
create one, you will analyze these similar properties to establish a
credible price range for your client. Offer to build CMAs for other
agents in your office for practice and invite them to critique your
work. You should be able to assemble a CMA efficiently and accurately,
as it is a fundamental tool you will use for all your listings and for
your prospecting. This is another activity that a more experienced agent
might hire you to assist with.

The challenge new agents face in securing listings can be linked to a
few factors. First, since the seller wants to sell their property
quickly at the highest possible price, they are more likely to
scrutinize your track record. Prospects can also pick up on your
confidence, or lack thereof, and they need to believe you can sell their
home successfully. To help build trust, find a friend or relative who
will list their home with you; they already know and trust you.


> **Friend & Family First Secret**: To jump-start your first sales, offer a “friends and family” commission discount to your relatives and close friends. You can also extend this insider treatment as a “special deal” to your first client in a new geographic farm. This approach generates immediate goodwill and makes new clients feel like they are being treated just like family.


As a new agent, gaining experience and closing deals are essential to
your success. The closing is the final step in a real estate
transaction, when all parties sign the necessary documents, funds are
exchanged, and ownership of the property is officially transferred from
the seller to the buyer. Importantly, this is when the brokerage gets
paid, and you earn your commission. It represents the completion of all
your efforts. Don't underestimate how a successful closing can boost
your confidence and motivate you to secure more listings. Also, a
listing tends to create a multiplier effect. A good rule of thumb is to
anticipate at least one buyer closing for every listing you have,
especially if you stay diligent in following up on open house leads and
yard sign calls.

To populate your Prospects database, you can rely on several
opportunities. For Sale By Owner (FSBO) refers to people who try to sell
their house without a real estate agent. There are also expired
listings: people who listed with a previous real estate agent, but that
agent failed to sell the house, so the listing has expired. You should
also volunteer for as much floor time as possible, which is the time
when an agent volunteers to help anyone who walks into the office
looking for a real estate agent.

Finally, begin scouting the neighborhoods you intend to specialize in.
Attend brokers’ open houses and preview homes listed for sale on the
MLS. You need to start identifying a geographic farm area for yourself,
which is a neighborhood you intend to focus on to generate clients.

Your real estate CRM can automatically load contact information from
various data sources. This process includes web forms, imports, or email
parsing—sometimes called **email feed**—which converts an email lead
notification into a prospect record.

## Working With a Mentor

While your broker is legally responsible for your supervision and
training, their time is often limited by their own business and
management duties. For this reason, I recommend that you seek an
additional mentor in the form of a successful, senior agent in your
office who can provide the practical guidance you'll need to get
started.


> **Back Scratcher Secret:** Look for opportunities where your success directly benefits your mentor. This can be assisting them with open houses, following up with leads they can’t get to, or taking overflow clients. When your growth adds to their production, you create a partnership where both of you are invested in each other’s success.


Find an agent you admire. Take them out to lunch and ask for advice. Not
all agents share the same goals as you do. For example, a semi-retired
agent might have more modest financial goals than a younger agent with a
family to support. Consider finding a mentor with similar objectives.
The lessons from your mentor will include work ethic, attitude, and
personal philosophy. Therefore, finding someone with a similar worldview
will be helpful.

## Training for New Agents

When you are just starting out, take advantage of every free training
opportunity. Taking classes offered by your broker and MLS, and learning
to use the advanced features of your MLS, are essential ways to build
your skills. Along with mentorship, your next key training focus should
be mastering your real estate CRM. When choosing your CRM, I recommend
prioritizing ease of use, video tutorials, and live phone support.
Initially, focus on tracking contacts and following up consistently. As
you become more comfortable with the core features, you can gradually
explore more advanced functions.

A good CRM provider offers different ways to learn the system, catering
to various learning styles. While video tutorials have become a common
way to learn how to use your CRM, written manuals can also be helpful,
especially for step-by-step instructions. Make sure the vendor you
choose has plenty of **video tutorials** that walk you through specific
features you might need. Avoid hour-long overviews. Instead, look for
tutorials that show you how to complete specific tasks. For example, if
you need to send a bulk email, find a 3-minute video demonstrating the
process, watch it, and finish your project in about 15 minutes.
Otherwise, you'll waste a lot of time trying to figure out simple tasks.

**Phone support** is essential for your real estate CRM. If you
encounter issues, call someone quickly, talk to them, and get help.
While it might seem acceptable to rely only on chat or email support,
you should avoid any real estate CRM that doesn't offer phone technical
support. Being able to speak with someone directly can mean the
difference between finishing a task in a day and being stuck for a week.

When choosing your real estate CRM vendor, test all their support
options during the trial period. How quickly can you reach a support
representative by phone during business hours? If you send an email with
a question, how long does it take to receive a reply? Real estate is a
fast-moving industry where quick task completion is crucial. If you can
learn to use your CRM efficiently, you'll be more productive and
successful.

While you will handle everything yourself at first, it is wise to plan
ahead and consider the possibility of hiring an assistant or bringing on
a partner as you become more experienced. Because turnover for real
estate assistants is quite high, you should choose CRM software that
requires minimal training and is easy for even a novice assistant to
operate.

Another responsibility you will have is meeting the **continuing
education** credit requirements to renew your license every few years.
You can monitor your progress and goals using the education section in
your real estate CRM. By keeping track of these formally, you can avoid
surprises from license renewal requirements that may take time and
planning to fulfill. Additionally, you might eventually want to pursue
more advanced licenses, such as a broker’s license. Your real estate CRM
can help you track your continuing education journey by noting the
credit hours required and those already completed.

## Becoming a Trusted Agent

Imagine how your prospects feel when they decide to buy or sell. They
are engaging in what is likely one of the most important financial
transactions of their lives. Buying or selling a home is not like buying
a loaf of bread; there are pitfalls and risks. It is your job to educate
your clients and give them sensible, accurate advice. Instead of a
salesperson, you are a trusted adviser and family friend. Wear
professional clothing. If you look professional, you'll face less
pushback when you ask for a professional commission. If you dress
casually, it may seem like you're cutting corners, and clients are then
more likely to expect a discount on your commission.

Use a business mailing address. While working from home is fine, avoid
using your home address as your mailing address. A professional office
helps you appear more established. Additionally, keeping your personal
and business lives separate is important, and sharing your home address
poses a security risk. If you don't have a professional business
address, consider options like Mailboxes Etc. This can make the absence
of an office less obvious.

I also recommend using a dedicated business email address. That way, you
are less likely to lose an email thread. Try to keep your email address
and phone number stable. This is how people will reach you. Five years
after a sale, if someone calls you to list their home, they need to be
able to reach you. If your phone number or email has changed, they may
be unable to find you!

Did you know that the average real estate agent stays with their broker
for less than 5 years[4]? Switching brokerages can be highly disruptive
to your prospecting pipeline. You will need to inform your friends and
past clients about any broker change. Some can be reached by phone,
others by email or printed letter, and still others via SMS text
message. Your real estate CRM can track who has been notified and who
still needs to be contacted. It may take an entire selling season for
everyone to become aware of your move to your new brokerage. This means
a decrease in income is likely with any change. Some of your past
clients may choose to stay with your old brokerage. Deals you are
working on before the move will probably stay with the old brokerage due
to legal requirements. Your real estate CRM can help you maintain
stability over time. For this reason, it can be seen as your insurance
policy against the income disruptions caused by changing brokerages.

Arrive on time or a little early for all your appointments. Use your
smartphone’s calendar and sync it with your CRM to keep everything up to
date. Being late or not showing up disrespects your clients’ time.
Modern smartphones remind you of your appointments and can even send
early notifications based on your location and driving times, giving you
enough time to get there.

Pay your bills on time. Your CRM can **track your expenses** and due
dates and help you create a budget. Set up automatic bank transfers to
handle your regular expenses, like your phone bill, so you never miss a
payment. Without your phone, you can’t do business.

If you commit to doing something, document it in your real estate CRM
and follow through on it, just as you promised. The real estate business
is fast-paced, and many things happen at once. For this reason, it is a
mistake to work purely from memory. Use your CRM to track your
obligations. You can use the task management features within your CRM to
create tasks that need to be completed and your calendar to track your
appointments.

Your office and desk should be kept tidy. If there's clutter, it'll be
harder to find things like keys, checks, paperwork, and other
essentials. Losing or having trouble locating items gives a bad
impression. For documents, I recommend keeping an electronic paper trail
in your CRM and Google Drive. You can’t lose files stored in the cloud,
and you can access them anytime, reducing the need to drive to your
office to pick up documents.


> **Elevator Answer Secret:** Always be able to answer the question: “How is the market?”. When you answer, it should be with an in-depth explanation that includes local inventory levels, average days on the market, and recent sales. Taking a step beyond “yes”, “no” or “it’s complicated” is important in selling yourself by showing that you are an authority on the market.


When you get a listing, one of the first things you’ll do is collect the
house keys from your seller. Don’t lose those keys! Use your CRM to
track their location and the tasks you need to complete with them. Have
you made copies? Did you return the originals yet? What about the
lockbox? And the yard sign? Again, your CRM can help you remember these
steps. When your listing sells, don’t forget to pick up your yard sign
and take the time to introduce yourself to the new buyer. I recommend
“adopting” the buyer by adding their contact information to your
database. That way, you can stay in touch by sending annual Christmas
cards and periodic just-listed/just-sold postcards, and by otherwise
demonstrating your expertise in the local real estate market. Your real
estate CRM includes standardized checklists, called task plans, for new
listings and closings. Take advantage of these plans and adjust them as
needed to fit your workflow.

The combination of all these factors will increase your income. After a
few years, you should expect a growing share of your clients to come
from repeat business and referrals[5]. These are the people who know
you. They are your friends. They do business with you because they like
and trust you. These deals also take considerably less time, since you
don’t have to spend as much time gaining their trust, which makes them
more likely to succeed.

## Building Sustainable Systems

Real estate is an uncertain business. Because you are paid only when a
deal closes, it can take months to determine which marketing strategies
work and which do not. While you may find strategies that produce
immediate results, you should expect that it will take time to reap the
full benefits of any plan you put into place. For this reason, you
should try a new marketing strategy each season and stick with it for
the full selling season before deciding whether it is effective. Your
real estate CRM is essential for this, as it lets you track each
prospect’s and contact’s lead source in your database. If you met
someone through a referral, enter the name of the person who referred
you as the lead source. At the end of the season, you can review your
closings to determine which lead sources produced income for you. You
can also review which lead sources turned into clients but produced no
income.

Some strategies will take longer than a single selling season to produce
results. Working a geographic farm, for example, will take longer than a
single selling season. Similarly, working your sphere of influence with
friends, family, and past clients takes time, as people do not move
every year, and you must play the long game.

While foundational strategies take time, one marketing approach that can
produce immediate results is purchasing leads from Zillow or another
third-party lead source. Unfortunately, these leads can be expensive,
and their quality is typically lower than that of other types of leads.
The key to working third-party leads is building a follow-up system
using your real estate CRM. That allows you to touch these leads several
times over the course of weeks or even months. You should use your CRM
to schedule a series of time-released drip emails or printed letters.

When working with online leads, your initial response time is arguably
the most critical controllable factor for success. This concept, known
as “**speed-to-lead**,” recognizes that a lead's interest is immediate
but fades within minutes. This golden window of opportunity is
shockingly brief. The urgency is best explained by intent. In the five
minutes after a prospect clicks “submit,” they are at their moment of
peak intent—actively focused on their problem and open to a solution.
After that, they've moved on to another website or task. A call at the
30-minute mark is no longer a helpful answer; it's an annoying
interruption. That lead could have easily contacted another agent in
those 3 minutes, and when you call, all you get is a busy signal! The
first agent to have a helpful, professional conversation often wins the
business.

The landmark 2007 research that defined this benchmark—a study by MIT
and InsideSales.com—found that responding within 5 minutes rather than
30 minutes makes you 21 times more likely to qualify the lead. This
finding was later confirmed and amplified in a 2011 Harvard Business
Review article, which further cemented the five-minute rule as a
critical business benchmark[6]. Given this rapid decay, your real estate
CRM is a vital tool, serving as the engine that automates, routes, and
triggers the immediate follow-up needed for your success.

You can feed internet leads directly into your CRM’s prospects database
using a technology called email feed. You will then be notified by email
and SMS text message of the new lead. That way, you can make an outgoing
call within minutes. When a lead asks about a specific property, you
must balance speed with preparation. Your first step is to review the
lead in your CRM and have that information on your screen before making
your call. Deep research can wait; the priority is to make a quick,
smart connection. Since you're competing with other real estate agents
for these leads, treat your first contact like a job interview. Be
professional and responsive to the inquiry. The ultimate goal of your
call is to schedule a face-to-face meeting.

Because of their high cost, new agents should avoid paid leads and first
hone their craft using sources that cost time rather than money, such as
open houses and floor time. You should also ask your broker about
obtaining leads from the company website or from shared paid lead
sources your broker already pays for, which are made available to all
agents in your office.

Another important strategy is to answer the phone when someone calls.
You should expect that when a prospect calls you, they are also looking
at other properties and talking with other agents. The first agent to
have a meaningful phone conversation is likely to get the business.
Professional attire is a given, but proper phone etiquette is also
critically important. For example, pay attention to the background noise
when you are talking on the phone. If there is a loud game show in the
background, your prospect might think you are not a hard worker. You
should also make sure you have a professional voicemail prompt and
return calls the same business day. Ensure your voicemail box is not
full by deleting messages after you have listened to them. Answer your
phone with your name and company, not just by saying “hello.” If you
will be unavailable due to illness or time off, make sure your voicemail
reflects this information.


> **The Lead Source Secret:** Whenever you add someone into your CRM, always label how they found you. This practice helps you identify which lead sources generate the most volume of leads. However, the number of leads is not as important as their profitability. At the end of each quarter, analyze your lead sources to see which ones generated closings. That way, you can focus on your most profitable lead sources.


To ensure no leads are missed, your real estate CRM may include a **call
capture** feature. This is a dedicated phone number that you can place
on sign riders (the smaller sign you attach to your main 'For Sale'
sign) and other marketing materials, allowing prospects to call or text
24/7 for property information. When someone calls and leaves a message,
the system automatically creates a new prospect record in your CRM. It
adds their name and phone number from the caller ID, along with a
complete **transcription of any voice message** added as a note. Your
CRM then notifies you of the new lead so you can respond immediately,
turning a missed call into a captured lead.

Your personality will play a large part in how you do business. I
recommend you become familiar with your personality by taking an online
personality test, such as the Myers-Briggs, to understand your
underlying strengths and what makes you happy. There are many ways to
achieve the same goals. An extrovert might pick up the phone and make
cold calls. An introvert might spend more time on social media,
advertising, and creating promotional videos. Both will generate fresh
leads, but in different ways. A large part of real estate involves
social situations, which tend to attract extroverts who rely on verbal
communication. However, an extrovert may be less interested in computer
work, which has increasingly become useful for agents in the age of the
internet and social media.

If you eventually hire an assistant or partner, consider someone with a
complementary personality. It is not unusual for an extrovert to hire an
introverted assistant. A real estate CRM is a great way to coordinate
your activities with a partner or assistant. That way, when you are in
the field, someone can handle office tasks, and both of you can access
the full deal record and make updates.

The job of a real estate salesperson is not a traditional 9-to-5 job.
Don’t be surprised if a client calls you in a panic on a Sunday evening.
This flexibility has its advantages. You do not have to punch a clock
and can take a Friday afternoon off to take your kids to a ball game.
But there are also challenges. This blending of personal and work life
means you must make a special effort to appear professional at all
times.

One excellent way to maintain a complete record of your transactions is
to use your real estate CRM to track offers and counteroffers. Having a
documentary trail of where you started allows you to review progress
dispassionately. Document everything, including contact information for
inspectors, loan officers, and closing companies. If a deal runs into a
snag, your detailed preparation gives you the tools needed to salvage
it.

Your real estate CRM helps you systematize your real estate agent
workflow. It allows you to organize and track your day so you never miss
an appointment and convert leads in a way that maximizes the likelihood
they become clients. Consistent follow-up is a key ingredient in this
process, and using checklists and plans helps you stay on track.

